"""Gain-stage every song so the meters read the same every Sunday.

  - each song group (all its stems summed, as the group meter shows them) peaks at -5 dB
  - the click peaks at -3 dB
  - guides peak at -7 dB
(targets in config.json -> "levels")

The audio is decoded and summed exactly as it will play (clip gain, track volume,
mutes, where each clip sits in the song), and every stem in a song moves by the
same amount so your mix balance is kept. Results are cached, so rebuilding is quick.
Needs numpy; it's installed automatically the first time if it's missing.
"""
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import tempfile

SR = 44100
MAX_GAIN = 1.99526          # Ableton fader top (+6 dB)
MIN_GAIN = 0.0003162278     # -70 dB
CLIP_MAX = 15.848932        # clip gain top (+24 dB)


def _set_gain(st, v):
    """Fader up to +6 dB; anything beyond goes on the clips' own gain. -> True if still short."""
    v = max(v, MIN_GAIN)
    if v <= MAX_GAIN:
        st.volume = v
        return False
    st.volume = MAX_GAIN
    extra, short = v / MAX_GAIN, False
    for c in st.clips:
        g = c.gain * extra
        if g > CLIP_MAX:
            g, short = CLIP_MAX, True
        c.gain = g
    return short
_np = None


def numpy():
    global _np
    if _np is None:
        try:
            import numpy as np
        except ImportError:
            try:
                subprocess.run([sys.executable, "-m", "pip", "install", "--user", "--quiet", "numpy"],
                               capture_output=True, timeout=600)
                import site
                import importlib
                site.addsitedir(site.getusersitepackages())
                importlib.invalidate_caches()
                import numpy as np
            except Exception:
                np = False
        _np = np
    return _np


def db(x):
    return 20 * math.log10(max(x, 1e-9))


def undb(d):
    return 10 ** (d / 20.0)


def _decode(path):
    """-> float32 array (frames, 2) at SR, or None."""
    np = numpy()
    tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    tmp.close()
    try:
        if shutil.which("afconvert"):
            cmd = ["afconvert", "-f", "WAVE", "-d", "LEI16@%d" % SR, "-c", "2", path, tmp.name]
        elif shutil.which("ffmpeg"):
            cmd = ["ffmpeg", "-v", "error", "-y", "-i", path, "-ac", "2", "-ar", str(SR), "-c:a", "pcm_s16le", tmp.name]
        else:
            return None
        subprocess.run(cmd, capture_output=True, timeout=300, check=True)
        import wave
        with wave.open(tmp.name) as w:
            ch = w.getnchannels()
            a = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2").astype(np.float32) / 32768.0
        a = a.reshape(-1, ch)
        if ch == 1:
            a = np.repeat(a, 2, axis=1)
        return a[:, :2]
    except (subprocess.SubprocessError, OSError, ValueError):
        return None
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


def _beats_to_sec(clip, beat):
    """File seconds for a file-beat position, using the clip's warp markers."""
    wm = sorted(clip.warp_markers or [(0.0, 0.0), (0.5, 1.0)])
    if len(wm) == 1:
        wm.append((wm[0][0] + 0.5, wm[0][1] + 1.0))
    pairs = list(zip(wm, wm[1:]))
    for (s0, b0), (s1, b1) in pairs:
        if beat <= b1 or (s1, b1) == wm[-1]:
            if b1 == b0:
                return s0
            return s0 + (beat - b0) * (s1 - s0) / (b1 - b0)
    return wm[-1][0]


def _render(stems, bpm, scale=None):
    """Sum stems as they'll play -> stereo peak (linear). scale: per-stem extra gain."""
    np = numpy()
    spb = 60.0 / (bpm or 120.0)
    mix = None
    for st in stems:
        if not st.on:
            continue
        for c in st.clips:
            a = _decode(c.path)
            if a is None:
                continue
            if c.warped:
                f0 = _beats_to_sec(c, c.loop_start + c.start_relative)
                f1 = _beats_to_sec(c, c.loop_start + c.start_relative + (c.end - c.start))
            else:
                f0, f1 = c.loop_start, c.loop_end
            seg = a[int(max(f0, 0) * SR):int(max(f1, 0) * SR)]
            if not len(seg):
                continue
            g = float(st.volume) * float(c.gain) * (scale.get(id(st), 1.0) if scale else 1.0)
            at = int(max(c.start, 0) * spb * SR)
            need = at + len(seg)
            if mix is None:
                mix = np.zeros((need, 2), dtype=np.float32)
            elif len(mix) < need:
                mix = np.concatenate([mix, np.zeros((need - len(mix), 2), dtype=np.float32)])
            mix[at:at + len(seg)] += seg * g
    if mix is None:
        return None
    return float(np.max(np.abs(mix)))


def _key(stems, bpm):
    h = hashlib.sha1()
    h.update(str(bpm).encode())
    for st in stems:
        for c in st.clips:
            try:
                stt = os.stat(c.path)
                h.update(("%s|%d|%d|%.3f|%.3f|%.3f|%.4f|%.4f|%s" % (c.path, stt.st_size, stt.st_mtime, c.start, c.end,
                          c.loop_start, c.gain, st.volume, st.on)).encode())
            except OSError:
                h.update(c.path.encode())
    return h.hexdigest()


class Leveler:
    def __init__(self, cfg, cache_path):
        lv = cfg.get("levels", {})
        self.enabled = lv.get("enabled", True)
        self.targets = {"song": lv.get("song_group_peak_db", -5.0), "click": lv.get("click_peak_db", -3.0),
                        "guide": lv.get("guide_peak_db", -7.0)}
        self.cache_path = cache_path
        try:
            with open(cache_path) as f:
                self.cache = json.load(f)
        except (OSError, ValueError):
            self.cache = {}

    def _peak(self, stems, bpm):
        k = _key(stems, bpm)
        if k not in self.cache:
            p = _render(stems, bpm)
            if p is None:
                return None
            self.cache[k] = p
        return self.cache[k]

    def apply(self, song, log=print):
        """Set every stem's volume so the targets are hit. Returns a short summary."""
        if not self.enabled:
            return ""
        if not numpy():
            song.warnings.append("Levels not set: couldn't install numpy (check the internet connection).")
            return ""
        groups = {"song": [s for s in song.stems if s.family not in ("click", "guide")],
                  "click": [s for s in song.stems if s.family == "click"]}
        out = []
        for name, stems in groups.items():
            if not stems or not any(s.on for s in stems):
                continue
            peak = self._peak(stems, song.bpm)
            if not peak:
                continue
            gain = undb(self.targets[name]) / peak
            short = False
            for s in stems:
                short = _set_gain(s, s.volume * gain) or short
            out.append("%s %+.1f dB" % ("group" if name == "song" else name, db(gain)))
            if short:
                song.warnings.append("%s is extremely quiet - even at full gain it peaks below %d dB."
                                     % ("The song" if name == "song" else "The click", self.targets[name]))
        for s in [s for s in song.stems if s.family == "guide" and s.on]:       # each guide on its own
            peak = self._peak([s], song.bpm)
            if peak:
                gain = undb(self.targets["guide"]) / peak
                if _set_gain(s, s.volume * gain):
                    song.warnings.append("%s is extremely quiet - even at full gain it peaks below %d dB."
                                         % (s.name, self.targets["guide"]))
                out.append("%s %+.1f dB" % (s.name, db(gain)))
        return ", ".join(out)

    def save(self):
        try:
            with open(self.cache_path, "w") as f:
                json.dump(self.cache, f)
        except OSError:
            pass
