"""Make what a stems-only song is missing: tempo + beat-1 grid, click with
count-in, section markers, and a spoken guide built from your cue pack.

Everything is measured from the stems themselves (numpy required)."""
import math
import os
import re
import shutil
import subprocess
import tempfile
import wave

AN_SR = 22050          # analysis rate
HOP = 512              # ~23 ms frames
FPS = AN_SR / float(HOP)
WIN = 2048
LATENCY = (WIN / 2.0) / AN_SR    # a frame "hears" a hit about half a window late
COUNT_IN_BEATS = 8     # 2 bars of 4/4


def np():
    from .levels import numpy as _n
    return _n()


# ---------------------------------------------------------------- audio

def load_mono(path, sr=AN_SR):
    n = np()
    tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    tmp.close()
    try:
        if shutil.which("afconvert"):
            cmd = ["afconvert", "-f", "WAVE", "-d", "LEI16@%d" % sr, "-c", "1", path, tmp.name]
        else:
            cmd = ["ffmpeg", "-v", "error", "-y", "-i", path, "-ac", "1", "-ar", str(sr), "-c:a", "pcm_s16le", tmp.name]
        subprocess.run(cmd, capture_output=True, timeout=300, check=True)
        with wave.open(tmp.name) as w:
            a = n.frombuffer(w.readframes(w.getnframes()), dtype="<i2").astype(n.float32) / 32768.0
        return a
    except (subprocess.SubprocessError, OSError, ValueError):
        return None
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


def _stft_mag(a):
    n = np()
    win = WIN
    if len(a) < win:
        a = n.pad(a, (0, win - len(a)))
    frames = 1 + (len(a) - win) // HOP
    idx = n.arange(win)[None, :] + HOP * n.arange(frames)[:, None]
    w = n.hanning(win).astype(n.float32)
    spec = n.abs(n.fft.rfft(a[idx] * w, axis=1)).astype(n.float32)
    return spec                                      # (frames, 1025)


_CHROMA = None


def _chroma_matrix(nbins=1025):
    global _CHROMA
    n = np()
    if _CHROMA is None:
        f = n.arange(nbins) * AN_SR / 2048.0
        m = n.zeros((nbins, 12), dtype=n.float32)
        ok = (f > 55) & (f < 2000)
        pc = (n.round(12 * n.log2(f[ok] / 440.0)) + 9) % 12
        m[n.where(ok)[0], pc.astype(int)] = 1.0
        _CHROMA = m
    return _CHROMA


def stem_features(a):
    """Per-frame: onset strength, low-band onset, energy, chroma."""
    n = np()
    S = _stft_mag(a)
    logS = n.log1p(100 * S)
    flux = n.maximum(n.diff(logS, axis=0, prepend=logS[:1]), 0)
    onset = flux.sum(axis=1)
    low = flux[:, 1:12].sum(axis=1)                 # < ~130 Hz (kick, bass attacks)
    energy = n.sqrt((S ** 2).mean(axis=1))
    chroma = S @ _chroma_matrix(S.shape[1])
    return {"onset": onset, "low": low, "energy": energy, "chroma": chroma}


# ---------------------------------------------------------------- tempo + grid

def _norm(x):
    n = np()
    x = x - n.median(x)
    x[x < 0] = 0
    s = x.std() or 1.0
    return x / s


def estimate_bpm(env, lo=60.0, hi=180.0):
    """Autocorrelation tempo with a gentle preference for 70-140 BPM."""
    n = np()
    e = env - env.mean()
    ac = n.correlate(e, e, mode="full")[len(e) - 1:]
    best, best_s = None, -1
    for bpm in n.arange(lo, hi, 0.5):
        lag = FPS * 60.0 / bpm
        s = 0.0
        for k, wgt in ((1, 1.0), (2, 0.5), (4, 0.25)):
            L = lag * k
            i = int(L)
            if i + 1 >= len(ac):
                continue
            s += wgt * (ac[i] * (1 - (L - i)) + ac[i + 1] * (L - i))
        prior = math.exp(-0.5 * (math.log2(bpm / 105.0) / 0.5) ** 2)
        s *= prior
        if s > best_s:
            best, best_s = bpm, s
    return float(best)


def _grid_score(env, bpm, phase):
    n = np()
    period = FPS * 60.0 / bpm
    pos = phase + period * n.arange(int((len(env) - phase) / period))
    i = pos.astype(int)
    f = pos - i
    ok = i + 1 < len(env)
    return float((env[i[ok]] * (1 - f[ok]) + env[i[ok] + 1] * f[ok]).sum())


def refine(env, bpm, span=1.0, step=0.01):
    """Exact tempo + beat phase (frames) that line up best with the onsets."""
    n = np()
    best = (bpm, 0.0, -1)
    for b in n.arange(bpm - span, bpm + span + 1e-9, step):
        period = FPS * 60.0 / b
        for ph in n.arange(0, period, 0.25):
            s = _grid_score(env, b, ph)
            if s > best[2]:
                best = (float(b), float(ph), s)
    b, ph, s = best
    # studio stems are almost always at a round (or half) tempo: snap if it fits as well
    for snap in (round(b), round(b * 2) / 2.0):
        if abs(snap - b) < 0.06:
            period = FPS * 60.0 / snap
            sp = max(((_grid_score(env, snap, p), p) for p in n.arange(0, period, 0.25)))
            if sp[0] >= 0.97 * s:
                return float(snap), float(sp[1])
    return b, ph


DB_WEIGHTS = (1.0, 3.0, 2.0, 1.5, 2.5)
LAST_PARTS = None


def downbeat(beat_frames, low_env, chroma, energy, entries, start_frame, weights=None):
    """Which of the 4 beats is beat 1. Evidence: kick/bass hits, chord changes,
    instruments entering, and the song's first note."""
    n = np()
    ch = chroma / (n.linalg.norm(chroma, axis=1, keepdims=True) + 1e-6)
    period = beat_frames[1] - beat_frames[0] if len(beat_frames) > 1 else 20
    parts = []
    for k in range(4):
        bf = beat_frames[k::4].astype(int)
        bf = bf[(bf > 8) & (bf < len(low_env) - 8)]
        if not len(bf):
            parts.append((0, 0, 0, 0))
            continue
        kick = float(n.mean([low_env[b - 1:b + 3].max() for b in bf])) / (low_env.mean() + 1e-6)
        change = float(n.mean([1 - float(ch[b + 3] @ ch[max(b - int(period * 0.5), 0)]) for b in bf]))
        entry = float(n.mean([entries[b - 2:b + 4].max() for b in bf])) / (entries.mean() + 1e-6)
        d = ((start_frame - beat_frames[k]) / period) % 4
        first = 1.0 if min(d, 4 - d) < 0.35 else 0.0
        # exported stems almost always begin on a bar line
        z = ((0 - beat_frames[k]) / period) % 4
        filestart = 1.0 if min(z, 4 - z) < 0.12 else 0.0
        parts.append((kick, change, entry, first, filestart))
    global LAST_PARTS
    P = n.array(parts, dtype=float)
    P = P / (P.max(axis=0, keepdims=True) + 1e-9)
    LAST_PARTS = P
    scores = P @ n.array(weights or DB_WEIGHTS)
    return int(n.argmax(scores))


class Analysis:
    pass


def analyze(song, families, known_bpm=None):
    """families: {stem_obj: family}. -> Analysis with bpm, first_downbeat_sec, bars, per-bar features."""
    n = np()
    feats = {}
    length = 0
    for st, fam in families.items():
        if fam in ("click", "guide") or not st.clips:
            continue
        a = load_mono(st.clips[0].path)
        if a is None or not len(a):
            continue
        f = stem_features(a)
        feats[st] = (fam, f)
        length = max(length, len(f["onset"]))
    if not feats:
        return None

    def total(key, fams=None):
        out = n.zeros(length, dtype=n.float32)
        for st, (fam, f) in feats.items():
            if fams and fam not in fams:
                continue
            x = f[key]
            out[:len(x)] += _norm(x.copy()) if key in ("onset", "low") else x
        return out

    rhythm = total("onset", ("drums", "bass")) if any(f[0] in ("drums",) for f in feats.values()) else total("onset")
    low = total("low", ("drums", "bass")) if any(f[0] in ("drums", "bass") for f in feats.values()) else total("low")
    chroma = n.zeros((length, 12), dtype=n.float32)
    for st, (fam, f) in feats.items():
        if fam in ("keys", "guitars", "bass"):
            chroma[:len(f["chroma"])] += f["chroma"]
    energy = total("energy")

    bpm0 = float(known_bpm) if known_bpm else estimate_bpm(rhythm)
    bpm, phase = refine(rhythm, bpm0, span=0.6 if known_bpm else 1.5)
    period = FPS * 60.0 / bpm
    beats = phase + period * n.arange(int((length - phase) / period))
    # instruments entering: per-stem energy rising from near silence
    entries = n.zeros(length, dtype=n.float32)
    for st, (fam, f) in feats.items():
        e = f["energy"]
        if e.max() <= 0:
            continue
        on = (e > 0.08 * e.max()).astype(n.float32)
        sm = n.convolve(on, n.ones(9) / 9, mode="same")
        rise = n.maximum(n.diff(sm, prepend=sm[:1]), 0)
        entries[:len(rise)] += rise
    thr = 0.05 * energy.max()
    start = int(n.argmax(energy > thr))
    db = downbeat(beats, low, chroma, energy, entries, start)
    first_db = phase + db * period                    # frames
    bar = 4 * period
    while first_db - bar >= -0.5 and first_db > start:
        first_db -= bar
    while first_db + bar <= start:
        first_db += bar

    an = Analysis()
    an.bpm = bpm
    an.first_downbeat = first_db / FPS + LATENCY      # seconds into the audio files
    an.bar_frames = bar
    an.phase = phase
    an.period = period
    an.n_frames = length
    an.feats = feats
    an.chroma = chroma
    an.energy = energy
    an.music_start = start / FPS
    return an


# ---------------------------------------------------------------- placement + click

def place_on_grid(song, an):
    """Warp every stem to the detected tempo and put the music's first bar after
    a 2-bar count-in (beat 1 lands on a bar line)."""
    bpm = an.bpm
    k = bpm / 60.0
    db_beats = an.first_downbeat * k                 # file-beat of the first downbeat
    s0 = COUNT_IN_BEATS - db_beats
    for st in song.stems:
        for c in st.clips:
            dur = (c.frames / float(c.sample_rate)) * k if c.frames and c.sample_rate else (c.end - c.start)
            c.warped = True
            c.warp_markers = [(0.0, 0.0), (1.0 / k, 1.0)]
            c.start_relative = 0.0
            if s0 >= 0:
                c.start, c.loop_start = s0, 0.0
            else:
                c.start, c.loop_start = 0.0, -s0
            c.loop_end = dur
            c.end = c.start + (dur - c.loop_start)
    song.bpm = round(bpm, 2)
    song.tempo = [(0.0, song.bpm)]
    song.length = max(c.end for st in song.stems for c in st.clips)
    song.length += -song.length % 4
    song.grid_from_audio = True


def _tone(n, sr, freq, ms=28, amp=0.9):
    t = n.arange(int(sr * ms / 1000.0)) / float(sr)
    env = n.exp(-t * 90.0)
    return (amp * n.sin(2 * n.pi * freq * t) * env).astype(n.float32)


def write_wav(path, mono, sr=44100):
    n = np()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    x = (n.clip(mono, -1, 1) * 32767).astype("<i2")
    st = n.stack([x, x], axis=1)
    with wave.open(path, "w") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(st.tobytes())


def render_click(path, bpm, beats, sr=44100, beats_per_bar=4):
    n = np()
    total = int((beats * 60.0 / bpm + 1.0) * sr)
    out = n.zeros(total, dtype=n.float32)
    hi, lo = _tone(n, sr, 1500), _tone(n, sr, 1000, amp=0.7)
    for b in range(int(beats)):
        i = int(round(b * 60.0 / bpm * sr))
        s = hi if b % beats_per_bar == 0 else lo
        out[i:i + len(s)] += s[:max(0, total - i)]
    write_wav(path, out, sr)
    return total, sr


# ---------------------------------------------------------------- sections

def bar_features(an):
    """-> (bar_times_sec, feature matrix bars x d, info per bar)"""
    n = np()
    bar_s = an.bar_frames / FPS
    t0 = an.first_downbeat - LATENCY
    nb = int((an.n_frames / FPS - t0) / bar_s)
    if nb < 4:
        return None
    rows, vox, bgv, energy = [], [], [], []
    stems = list(an.feats.items())
    E = n.zeros((nb, len(stems)), dtype=n.float32)
    C = n.zeros((nb, 12), dtype=n.float32)
    for k in range(nb):
        a = int((t0 + k * bar_s) * FPS)
        b = int((t0 + (k + 1) * bar_s) * FPS)
        a = max(a, 0)
        for j, (st, (fam, f)) in enumerate(stems):
            seg = f["energy"][a:b]
            E[k, j] = float(seg.mean()) if len(seg) else 0.0
        c = an.chroma[a:b].mean(axis=0) if b > a else n.zeros(12)
        C[k] = c / (n.linalg.norm(c) + 1e-6)
    mx = E.max(axis=0, keepdims=True) + 1e-9
    P = (E / mx > 0.12).astype(n.float32)            # which stems are playing
    L = n.log10(E / mx + 1e-3)
    L = (L - L.mean(axis=0)) / (L.std(axis=0) + 1e-6)
    fams = [fam for st, (fam, f) in stems]
    names = [st.name.lower() for st, _ in stems]
    lead = n.array([1.0 if (fam == "vocals" and "lead" in nm) else 0.0 for fam, nm in zip(fams, names)])
    bg = n.array([1.0 if (fam == "vocals" and "lead" not in nm) else 0.0 for fam, nm in zip(fams, names)])
    info = {"presence": P, "lead": (P * lead).sum(axis=1), "bgv": (P * bg).sum(axis=1),
            "energy": (E / mx).mean(axis=1), "count": P.sum(axis=1), "fams": fams}
    X = n.concatenate([L, P * 1.5, C * 2.0], axis=1)
    return t0, bar_s, X, info


def find_sections(an, sequence=None, min_bars=4):
    """-> [(start_bar, end_bar, name)] relative to the first downbeat bar."""
    n = np()
    bf = bar_features(an)
    if not bf:
        return []
    t0, bar_s, X, info = bf
    nb = len(X)
    music = n.where(info["count"] > 0)[0]
    if not len(music):
        return []
    first, last = int(music[0]), int(music[-1]) + 1
    Xn = X / (n.linalg.norm(X, axis=1, keepdims=True) + 1e-6)
    S = Xn @ Xn.T
    K = 4
    nov = n.zeros(nb)
    for b in range(first + 2, last - 1):
        a0, a1, b1 = max(first, b - K), b, min(last, b + K)
        past, fut = S[a0:a1, a0:a1], S[a1:b1, a1:b1]
        cross = S[a0:a1, a1:b1]
        nov[b] = past.mean() + fut.mean() - 2 * cross.mean()
        # instruments coming in / dropping out is a strong section cue
        nov[b] += 0.15 * float(n.abs(info["presence"][b] - info["presence"][b - 1]).sum())
    # favour 4-bar phrase lines counted from the first bar of music
    w = n.array([1.0 if (b - first) % 4 == 0 else (0.55 if (b - first) % 2 == 0 else 0.25) for b in range(nb)])
    score = nov * w
    thr = score[first:last].mean() + 0.35 * score[first:last].std()
    cands = [b for b in range(first + 1, last - 1)
             if score[b] > thr and score[b] >= score[max(b - 2, 0):b + 3].max()]
    bounds = [first]
    for b in sorted(cands, key=lambda b: -score[b]):
        if all(abs(b - x) >= min_bars for x in bounds) and last - b >= min_bars // 2:
            bounds.append(b)
    bounds = sorted(bounds) + [last]
    segs = [(bounds[i], bounds[i + 1]) for i in range(len(bounds) - 1) if bounds[i + 1] > bounds[i]]

    # group segments that sound alike (same section coming back)
    M = n.array([X[a:b].mean(axis=0) for a, b in segs])
    Mn = M / (n.linalg.norm(M, axis=1, keepdims=True) + 1e-6)
    groups, gid = [], []
    for i in range(len(segs)):
        g = next((j for j, rep in enumerate(groups) if float(Mn[i] @ Mn[rep]) > 0.86), None)
        if g is None:
            groups.append(i)
            g = len(groups) - 1
        gid.append(g)
    return _name_sections(segs, gid, info, sequence)


def _name_sections(segs, gid, info, sequence):
    from .cues import section_name
    n = np()
    seq = [section_name(x) for x in (sequence or []) if str(x).strip()]
    if seq and len(seq) == len(segs):
        return [(a, b, nm) for (a, b), nm in zip(segs, seq)]
    nseg = len(segs)
    E = [float(info["energy"][a:b].mean()) for a, b in segs]
    V = [float((info["lead"][a:b] + info["bgv"][a:b]).mean()) for a, b in segs]
    B = [float(info["bgv"][a:b].mean()) for a, b in segs]
    count = {}
    for g in gid:
        count[g] = count.get(g, 0) + 1
    names = [None] * nseg
    # chorus: the loudest repeating group with the most background vocals
    rep = [g for g in count if count[g] > 1]
    if rep:
        def gscore(g):
            ix = [i for i in range(nseg) if gid[i] == g]
            return n.mean([E[i] for i in ix]) + 0.5 * n.mean([B[i] for i in ix])
        chorus = max(rep, key=gscore)
        for i in range(nseg):
            if gid[i] == chorus:
                names[i] = "CHORUS"
        others = [g for g in rep if g != chorus]
        if others:
            verse = max(others, key=lambda g: count[g])
            for i in range(nseg):
                if gid[i] == verse and names[i] is None:
                    names[i] = "VERSE"
    for i in range(nseg):
        if names[i]:
            continue
        a, b = segs[i]
        if i == 0 and V[i] < 0.5:
            names[i] = "INTRO"
        elif i == nseg - 1:
            names[i] = "OUTRO" if E[i] < max(E) * 0.8 else "TAG"
        elif i + 1 < nseg and names[i + 1] == "CHORUS" and b - a <= 4:
            names[i] = "PRE CHORUS"
        elif V[i] < 0.3:
            names[i] = "INTERLUDE"
        elif i > nseg * 0.5:
            names[i] = "BRIDGE"
        else:
            names[i] = "VERSE"
    return [(a, b, nm) for (a, b), nm in zip(segs, names)]
