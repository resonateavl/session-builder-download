"""Assemble a Sunday set: template + songs -> one arrangement-view .als."""
import json
import math
import os
import re
import shutil

from . import als
from . import memory as cue_memory
from .songs import apply_memory, is_marker_track, load_song

ROOT_DIR = als.ROOT_DIR
CONFIG_PATH = os.path.join(ROOT_DIR, "config.json")


def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)


def standard_name(name, song_title, cfg):
    """'03 Trusting For A Miracle_Bass Stem' -> 'Bass', 'Electric_2' -> 'EG 2', 'Bateria' -> 'Drums'."""
    n = name.replace("_", " ").strip()
    n = re.sub(r"\[\d{4}-\d\d-\d\d \d+\]", "", n)           # Ableton consolidate stamps
    n = re.sub(r"^\s*\d{1,3}\s*[-.)]?\s+", "", n)                # track numbers
    if song_title:
        n = re.sub(re.escape(song_title), "", n, flags=re.I)
    n = re.sub(r"\b(stems?|track|audio)\s*$", "", n, flags=re.I)
    n = re.sub(r"\s*[-:]\s*$|^\s*[-:]\s*", "", n)
    n = re.sub(r"\s+", " ", n).strip() or name
    low = n.lower()
    for rule in cfg.get("stem_names", []):
        m = re.search(rule["match"], low)
        if m:
            out = rule["name"]
            nums = [g for g in m.groups() if g and re.fullmatch(r"\s*0?\d+\s*", g)]
            num = str(int(nums[-1])) if nums else ""
            out = re.sub(r"\s+", " ", out.replace("{n}", num))
            return out.strip()
    return n if n != n.lower() else n.title()


def classify(stem_name, cfg):
    n = stem_name.lower()
    for rule in cfg["stem_rules"]:
        if re.search(rule["match"], n):
            return rule["family"]
    return cfg["default_family"]


def return_map(return_names, cfg):
    """family -> index of the return track it sends to."""
    names = [r.upper() for r in return_names]
    out = {}
    for fam, spec in cfg["families"].items():
        idx = None
        for kw in spec["returns"]:
            for i, n in enumerate(names):
                if kw.upper() in n:
                    idx = i
                    break
            if idx is not None:
                break
        out[fam] = idx
    # Fallbacks: families with no matching return use the fallback family's return.
    for fam, spec in cfg["families"].items():
        f = spec.get("fallback")
        while out.get(fam) is None and f:
            out[fam] = out.get(f)
            f = cfg["families"][f].get("fallback")
        if out.get(fam) is None and names:
            out[fam] = 0
    return out


def _guide_clips(guides):
    """All clips of the spoken-cue guide track(s), not vocal guides."""
    spoken = [g for g in guides if "vocal" not in g.name.lower()] or guides[:1]
    return [c for g in spoken for c in g.clips]


def _guide_markers(song, cfg, log):
    """No markers anywhere: listen to the guide track for section cues."""
    from .cues import detect_markers
    guides = [st for st in song.stems if classify(standard_name(st.name, song.title, cfg), cfg) == "guide"]
    guides.sort(key=lambda st: ("vocal" in st.name.lower(), st.name))
    if not guides:
        song.warnings.append("No section markers and no guide track to listen to.")
        return
    found, note = detect_markers(song, _guide_clips(guides), getattr(song, "pco_sequence", None))
    song.warnings = [w for w in song.warnings if "No section markers" not in w]
    if not found:
        song.warnings.append("No section markers (%s)." % note)
        return
    song.markers = found
    song.cues = []
    song.marker_source = "guide track (%s)" % note
    song.warnings = [w for w in song.warnings if "No section markers" not in w]


DEFAULT_STOP = {
    "routing": {"Target": "MidiOut/External.Dev:IAC Driver (Bus 1)/0",
                "UpperDisplayString": "IAC Driver (Bus 1)", "LowerDisplayString": "Ch. 1"},
    "color": 14, "len": 4.0, "name": "STOP",
    "keytracks": ['<KeyTrack Id="0"><Notes><MidiNoteEvent Time="0" Duration="4" Velocity="100" '
                  'OffVelocity="64" NoteId="1" /></Notes><MidiKey Value="2" /></KeyTrack>'],
}


def _stop_template(memory_files):
    """Your most recent STOP clip (note, routing, length) from past sessions."""
    best = None
    for v in (memory_files or {}).values():
        for r in v["songs"]:
            for t in r["tracks"]:
                if "STOP" in t["track"].upper() and t["clips"] and (best is None or v["mtime"] > best[0]):
                    c = t["clips"][0]
                    best = (v["mtime"], {"routing": t.get("routing") or DEFAULT_STOP["routing"],
                                         "color": t.get("color", 14), "len": c["len"] or 4.0,
                                         "name": c["name"] or "STOP",
                                         "keytracks": c.get("keytracks") or DEFAULT_STOP["keytracks"],
                                         "track": t["track"]})
    return best[1] if best else dict(DEFAULT_STOP, track="STOP")


def _add_stop(song, cfg, memory_files):
    """STOP at the end of the song, unless your own cues for it already have one."""
    if any("STOP" in ct["track"].upper() and ct["clips"] for ct in song.cues):
        return
    tpl = _stop_template(memory_files)
    end = _song_end(song)
    if not song.cues and song.markers:
        song.cues = [{"track": "MARKERS", "routing": None, "color": cfg["markers_color"],
                      "clips": [{"start": a, "len": b - a, "name": n, "color": cfg["markers_color"], "keytracks": []}
                                for a, b, n in song.markers]}]
    song.cues.append({"track": tpl["track"], "routing": tpl["routing"], "color": tpl["color"],
                      "clips": [{"start": end, "len": tpl["len"], "name": tpl["name"], "color": tpl["color"],
                                 "keytracks": tpl["keytracks"]}]})


def _fill_gaps(song, cfg):
    """Song has markers, but some part of it has none: add sections from the guide there."""
    from .cues import detect_markers
    guides = [st for st in song.stems if classify(standard_name(st.name, song.title, cfg), cfg) == "guide"]
    guides.sort(key=lambda st: ("vocal" in st.name.lower(), st.name))
    if not guides or not song.markers:
        return
    try:
        found, _ = detect_markers(song, _guide_clips(guides), getattr(song, "pco_sequence", None))
    except Exception:
        return
    if not found:
        return
    covered = [(a, b) for a, b, _ in song.markers]
    starts = sorted(a for a, _ in covered)
    added = []
    for a, b, name in found:
        if name == "COUNT IN" and starts and starts[0] <= 8:
            continue
        if any(ca - 0.5 <= a < cb - 0.5 for ca, cb in covered):
            continue
        nxt = min([x for x in starts if x > a] + [b])
        if nxt - a < 2:
            continue
        added.append((a, nxt, name))
    if not added:
        return
    song.markers = sorted(song.markers + added)
    mk = next((ct for ct in song.cues if is_marker_track(ct["track"])), None)
    if mk is None and song.cues:
        mk = {"track": "MARKERS", "routing": None, "color": cfg["markers_color"], "clips": []}
        song.cues.insert(0, mk)
    if mk is not None:
        color = mk["clips"][0]["color"] if mk["clips"] else cfg["markers_color"]
        for a, b, n in added:
            mk["clips"].append({"start": a, "len": b - a, "name": n, "color": color, "keytracks": []})
    song.warnings.append("Added %d marker%s from the guide where there were none (%s)."
                         % (len(added), "" if len(added) == 1 else "s", ", ".join(n for _, _, n in added[:6])))


def song_label(n, song):
    title = re.sub(r"\s*[\(\[](feat|ft|con|en vivo|live)\.?[^\)\]]*[\)\]]", "", song.title, flags=re.I).strip()
    parts = [str(n), title.upper()]
    if song.key:
        parts.append(song.key)
    bpm = song.label_bpm or song.bpm
    if bpm:
        parts.append(("%g" % round(bpm, 1)))
    return "-".join(parts)


def _song_end(song):
    """Where the next song should start (beats, song-relative): after the last
    marker AND after the audio, so songs never overlap."""
    audio_end = max([c.end for st in song.stems for c in st.clips] or [0.0])
    marker_end = max([m[1] for m in song.markers] or [0.0])
    end = max(audio_end, marker_end, song.length if not song.stems else 0.0)
    return end + (-end % 4)


def _existing(ls):
    """What's already in a session we're adding songs to."""
    tracks = list(ls.find("Tracks"))
    by_id = {t.get("Id"): t for t in tracks}

    def root(t):
        for _ in range(12):
            g = als.val(t, "TrackGroupId", "-1")
            if g == "-1" or g not in by_id:
                return t
            t = by_id[g]
        return t

    info = {"root": root, "tracks": tracks}
    info["cue"] = {}
    for t in tracks:
        if t.tag == "MidiTrack" and als.val(t, "TrackGroupId", "-1") == "-1":
            nm = als.track_name(t)
            key = "MARKERS" if is_marker_track(nm) else nm.upper()
            info["cue"].setdefault(key, t)
    info["clicks"] = next((t for t in tracks if t.tag == "GroupTrack" and "CLICK" in als.track_name(t).upper()), None)
    info["guides"] = next((t for t in tracks if t.tag == "GroupTrack" and "GUIDE" in als.track_name(t).upper()), None)
    info["songs"] = [t for t in tracks if t.tag == "GroupTrack" and re.match(r"^\s*\d+\s*-", als.track_name(t))]
    end = 0.0
    for t in tracks:
        for ev in t.iter("ArrangerAutomation"):
            for c in ev.findall("Events/AudioClip") + ev.findall("Events/MidiClip"):
                try:
                    end = max(end, float(als.val(c, "CurrentEnd")))
                except (TypeError, ValueError):
                    pass
    for l in ls.find("Locators/Locators"):
        end = max(end, float(als.val(l, "Time", 0)))
    info["end"] = end + (-end % 4)
    return info


def _last_of(info_tracks, root, group):
    """Last track inside a group (the group itself if it's empty)."""
    last = group
    for t in info_tracks:
        if t is not group and root(t) is group:
            last = t
    return last


def _insert_after(tracks_el, anchor, items):
    kids = list(tracks_el)
    i = kids.index(anchor) + 1 if anchor is not None and anchor in kids else 0
    for k, t in enumerate(items):
        tracks_el.insert(i + k, t)


def _insert_into_existing(tracks_el, ex, new_cue_tracks, clicks, click_children, guides, guide_children, song_tracks):
    root = ex["root"]
    # new cue tracks go right after the existing cue tracks (or at the top)
    cue_anchor = None
    for t in list(tracks_el):
        if t.tag == "MidiTrack" and als.val(t, "TrackGroupId", "-1") == "-1" and t not in new_cue_tracks:
            cue_anchor = t
    if new_cue_tracks:
        _insert_after(tracks_el, cue_anchor, new_cue_tracks)
    for grp, kids, existed in ((clicks, click_children, ex["clicks"] is not None),
                               (guides, guide_children, ex["guides"] is not None)):
        if existed:
            _insert_after(tracks_el, _last_of(list(tracks_el), root, grp), kids)
        else:
            anchor = new_cue_tracks[-1] if new_cue_tracks else cue_anchor
            _insert_after(tracks_el, anchor, [grp] + kids)
    # new songs after your last song (or after GUIDES if the session had none)
    if ex["songs"]:
        anchor = _last_of(list(tracks_el), root, ex["songs"][-1])
    else:
        anchor = _last_of(list(tracks_el), root, guides)
    block = []
    for grp, children in song_tracks:
        block += [grp] + children
    _insert_after(tracks_el, anchor, block)


def build_set(template_path, entries, out_path, cfg=None, gap_bars=0, copy_audio=False, log=print, path_map=None,
              memory_files=None, append=False):
    """entries: list of dicts {path, title?, key?, bpm?} in service order,
    or already-loaded Song objects.  append=True: template_path is one of your
    sessions - the songs are added after its last song."""
    cfg = cfg or load_config()
    protos = als.Prototypes()
    tree = als.load(template_path)
    ls = tree.getroot().find("LiveSet")
    tracks_el = ls.find("Tracks")
    ids = als.IdAllocator(ls)
    returns = [als.track_name(t) for t in tracks_el.findall("ReturnTrack")]
    n_ret = len(returns)
    n_scenes = len(ls.find("Scenes"))
    rmap = return_map(returns, cfg)
    fams = cfg["families"]
    log(("Adding to %s - returns: " % os.path.basename(template_path) if append else "Template returns: ")
        + ", ".join("%s" % r for r in returns))
    ex = _existing(ls) if append else None
    from .levels import Leveler
    leveler = Leveler(cfg, os.path.join(als.DATA_DIR, "levels_cache.json"))

    songs = []
    for e in entries:
        if hasattr(e, "stems"):
            songs.append(e)
            continue
        s = load_song(e["path"], **{k: e[k] for k in ("bpm", "key", "title") if e.get(k) and not e["path"].lower().endswith(".als")})
        if e.get("title"):
            s.title = e["title"]
        if e.get("key"):
            s.key = e["key"]
        s.pco_sequence = e.get("sequence") or []
        songs.append(s)

    # Your own markers/cues from past sessions win over everything else.
    for s in songs:
        if memory_files:
            rec = cue_memory.find(memory_files, s.title, s.key,
                                  [os.path.basename(c.path) for st in s.stems for c in st.clips],
                                  exclude=os.path.abspath(out_path))
            if rec:
                apply_memory(s, rec)
        if not s.marker_source:
            _guide_markers(s, cfg, log)
        else:
            _fill_gaps(s, cfg)
        if cfg.get("stop_after_each_song", {}).get("enabled", True):
            _add_stop(s, cfg, memory_files)
        if not s.cues and s.markers:
            s.cues = [{"track": "MARKERS", "routing": None, "color": cfg["markers_color"],
                       "clips": [{"start": a, "len": b - a, "name": n, "color": cfg["markers_color"], "keytracks": []}
                                 for a, b, n in s.markers]}]

    def sends_for(fam, level=1.0):
        v = [0.0] * n_ret
        i = rmap.get(fam)
        if i is not None and n_ret:
            v[i] = level
        return v

    new_tracks = []

    # MIDI cue tracks (MARKERS first, then REPEAT / STOP / etc. in the order first seen)
    cue_names = ["MARKERS"]
    for sg in songs:
        for ct in sg.cues:
            nm = "MARKERS" if is_marker_track(ct["track"]) else ct["track"]
            if nm not in cue_names:
                cue_names.append(nm)
    cue_tracks, cue_clip_ids = {}, {}
    new_cue_tracks = []
    for nm in cue_names:
        if ex and (ex["cue"].get(nm) is not None or ex["cue"].get(nm.upper()) is not None):
            t = ex["cue"].get(nm) or ex["cue"].get(nm.upper())
            cue_tracks[nm] = t
            cue_clip_ids[nm] = 1 + max([int(c.get("Id", 0)) for c in als.midi_events(t)] + [-1])
            continue
        src = next((ct for sg in songs for ct in sg.cues
                    if ("MARKERS" if is_marker_track(ct["track"]) else ct["track"]) == nm), None)
        t = als.new_track("midi", protos, ids, nm, (src or {}).get("color", cfg["markers_color"]) if nm != "MARKERS" else cfg["markers_color"])
        als.fill_track_slots(t, protos, n_scenes, [0.0] * n_ret, ids)
        if src and src.get("routing"):
            als.set_midi_output(t, src["routing"])
        cue_tracks[nm] = t
        cue_clip_ids[nm] = 0
        new_tracks.append(t)
        new_cue_tracks.append(t)

    if ex and ex["clicks"] is not None:
        clicks = ex["clicks"]
    else:
        clicks = als.new_track("group", protos, ids, "CLICKS", fams["click"]["color"])
        als.fill_track_slots(clicks, protos, n_scenes, sends_for("click"), ids)
        als.route_output(clicks, "sends")
    if ex and ex["guides"] is not None:
        guides = ex["guides"]
    else:
        guides = als.new_track("group", protos, ids, "GUIDES", fams["guide"]["color"])
        als.fill_track_slots(guides, protos, n_scenes, sends_for("guide"), ids)
        als.route_output(guides, "sends")
    click_children, guide_children, song_tracks = [], [], []

    locators = ls.find("Locators/Locators")
    tempo_pts, sig_pts = [], []
    if ex:
        loc_id = 1 + max([int(l.get("Id", 0)) for l in locators] + [-1])
        auto = als.read_master_automation(ls)
        tempo_pts = [(0.0 if t < 0 else t, v) for t, v in auto["tempo"]]
        sig_pts = [(0.0 if t < 0 else t, v) for t, v in auto["sig"]]
        pos = ex["end"] + gap_bars * 4
        n_before = len(ex["songs"])
        log("Your session has %d song%s and ends at bar %d - adding after it."
            % (n_before, "" if n_before == 1 else "s", ex["end"] / 4 + 1))
    else:
        locators[:] = []
        loc_id = 0
        pos = 0.0
        n_before = 0
    family_order = list(fams.keys())
    project_dir = os.path.dirname(out_path)

    for n, song in enumerate(songs, n_before + 1):
        label = song_label(n, song)
        log("Placing %s at bar %d" % (label, pos / 4 + 1))
        am = cfg.get("auto_mute", {})
        muted = []
        for st in song.stems:
            st.name = standard_name(st.name, song.title, cfg)
            st.family = classify(st.name, cfg)
            if am.get("enabled", True) and st.on and any(re.search(m, st.name.lower()) for m in am.get("match", [])):
                st.on = False
                muted.append(st.name)
        if muted:
            log("  turned off: " + ", ".join(muted))
        lv = leveler.apply(song, log)
        if lv:
            log("  levels: " + lv)
        if copy_audio:
            _collect(song, os.path.join(project_dir, "Samples", "Imported", _safe(label)))

        # --- MIDI cues (markers, repeat, stop ...) + locators
        if song.marker_source:
            log("  markers: " + song.marker_source)
        for ct in song.cues:
            nm = "MARKERS" if is_marker_track(ct["track"]) else ct["track"]
            t = cue_tracks[nm]
            for c in ct["clips"]:
                name = c["name"].upper() if nm == "MARKERS" else c["name"]
                als.midi_events(t).append(als.make_midi_clip(
                    protos, cue_clip_ids[nm], pos + c["start"], pos + c["start"] + c["len"], name,
                    c.get("color", cfg["markers_color"]), c.get("keytracks")))
                cue_clip_ids[nm] += 1
        song_loc_times = set()
        locators.append(als.make_locator(protos, loc_id, pos, label))
        loc_id += 1
        song_loc_times.add(0.0)
        if cfg.get("section_locators", True):
            for (a, b, name) in song.markers:
                if a in song_loc_times:
                    continue
                song_loc_times.add(a)
                locators.append(als.make_locator(protos, loc_id, pos + a, name.upper()))
                loc_id += 1

        # --- tempo / time signature
        for pts, src in ((tempo_pts, song.tempo), (sig_pts, song.sig)):
            first = src[0][1]
            if not pts:
                pts.append((pos, first))
            elif pts[-1][1] != first:
                pts.append((pos, pts[-1][1]))
                pts.append((pos, first))
            for t, v in src[1:]:
                pts.append((pos + t, v))

        # --- audio tracks
        grp = als.new_track("group", protos, ids, label, cfg["song_group_color"])
        als.fill_track_slots(grp, protos, n_scenes, [0.0] * n_ret, ids)
        als.route_output(grp, "sends")
        children = []
        ordered = sorted(song.stems, key=lambda s: family_order.index(s.family) if s.family in family_order else 99)
        for st in ordered:
            fam = st.family
            if fam == "click":
                parent = clicks
                bucket = click_children
            elif fam == "guide":
                parent = guides
                bucket = guide_children
            else:
                parent = grp
                bucket = children
            t = als.new_track("audio", protos, ids, st.name, fams[fam]["color"], int(parent.get("Id")))
            # stems inside CLICKS/GUIDES send via their group, others send directly
            sends = [0.0] * n_ret if fam in ("click", "guide") else sends_for(fam)
            als.fill_track_slots(t, protos, n_scenes, sends, ids)
            als.route_output(t, "group")
            als.set_mixer(t, st.volume, st.on)
            ev = als.audio_events(t)
            for i, c in enumerate(st.clips):
                if path_map and c.path.startswith(path_map[0]):
                    c.path = path_map[1] + c.path[len(path_map[0]):]
                ev.append(als.make_audio_clip(protos, i, c, pos, fams[fam]["color"]))
            bucket.append(t)
        song_tracks.append((grp, children))
        for w in song.warnings:
            log("  note: " + w)
        pos += _song_end(song) + gap_bars * 4

    if not tempo_pts:
        raise ValueError("No songs to build")
    als.write_master_automation(ls, tempo_pts, sig_pts, ids)

    if not ex:
        new_tracks.append(clicks)
        new_tracks += click_children
        new_tracks.append(guides)
        new_tracks += guide_children
        for grp, children in song_tracks:
            new_tracks.append(grp)
            new_tracks += children
        for i, t in enumerate(new_tracks):
            tracks_el.insert(i, t)
    else:
        _insert_into_existing(tracks_el, ex, new_cue_tracks, clicks, click_children,
                              guides, guide_children, song_tracks)
    leveler.save()
    ids.commit()
    os.makedirs(project_dir, exist_ok=True)
    als.save(tree, out_path)
    if append:
        log("Added %d song%s to %s (now ends at bar %d)" % (len(songs), "" if len(songs) == 1 else "s", out_path, pos / 4 + 1))
    else:
        log("Saved %s (%d songs, %d tracks, %d bars)" % (out_path, len(songs), len(new_tracks), pos / 4))
    return songs


def _safe(s):
    return re.sub(r'[/:\\*?"<>|]', "_", s)


def _collect(song, dest):
    os.makedirs(dest, exist_ok=True)
    for st in song.stems:
        for c in st.clips:
            target = os.path.join(dest, os.path.basename(c.path))
            if not (os.path.exists(target) and os.path.getsize(target) == os.path.getsize(c.path)):
                shutil.copy2(c.path, target)
            c.path = target
