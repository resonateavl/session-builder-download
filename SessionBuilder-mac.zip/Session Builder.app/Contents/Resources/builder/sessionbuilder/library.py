"""Index the stems library and match setlist titles to songs."""
import json
import os
import re
import time
import unicodedata

from .songs import AUDIO_EXT, parse_name

SKIP_DIRS = {"Backup", "Ableton Project Info", "System Volume Information", "Waves", "Session Builder",
             "Samples", "Processed", "Recorded", "Freeze", "Consolidate"}
SKIP_ALS = re.compile(r"template|cue ?pack|tempo track", re.I)


def norm(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()
    s = re.sub(r"\(.*?\)|\[.*?\]", " ", s)
    s = re.sub(r"[^a-z0-9 ]+", " ", s)
    return " ".join(s.split())


def scan(root, log=print):
    """Find every song: each .als (MultiTracks/LC/custom set) and every stems folder
    that has no .als of its own."""
    entries = []
    t0 = time.time()
    for d, dirs, files in os.walk(root):
        dirs[:] = sorted(x for x in dirs if not x.startswith(".") and x not in SKIP_DIRS)
        als_files = [f for f in files if f.lower().endswith(".als") and not f.startswith("._")]
        audio = [f for f in files if f.lower().endswith(AUDIO_EXT) and not f.startswith("._")]
        for f in als_files:
            if SKIP_ALS.search(f):
                continue
            p = os.path.join(d, f)
            title, key, bpm = parse_name(f)
            t2, k2, b2 = parse_name(os.path.basename(d))
            if not title or re.match(r"^(multi ?tracks?|untitled)$", title, re.I) or len(t2) > len(title):
                title = t2 or title
            entries.append({"path": p, "kind": "als", "title": title, "key": key or k2,
                            "bpm": bpm or b2, "where": os.path.relpath(d, root)})
        if len(audio) >= 3:
            parent = os.path.dirname(d)
            has_als = als_files or any(f.lower().endswith(".als") for f in _ls(parent))
            if not has_als:
                base = os.path.basename(d)
                title, key, bpm = parse_name(base)
                if not title or re.match(r"^(for )?(multi ?tracks?|stems|audio)$", base, re.I):
                    title, key, bpm = parse_name(os.path.basename(parent))
                entries.append({"path": d, "kind": "stems", "title": title, "key": key, "bpm": bpm,
                                "where": os.path.relpath(d, root), "n": len(audio)})
    log("Indexed %d songs in %.0fs" % (len(entries), time.time() - t0))
    return entries


def _ls(d):
    try:
        return os.listdir(d)
    except OSError:
        return []


def load_index(root, cache_path, rescan=False, log=print):
    if not rescan and os.path.exists(cache_path):
        with open(cache_path) as f:
            data = json.load(f)
        if data.get("root") == root:
            return data["entries"]
    entries = scan(root, log)
    with open(cache_path, "w") as f:
        json.dump({"root": root, "time": time.time(), "entries": entries}, f)
    return entries


def search(entries, q, key=None, limit=12):
    nq = norm(q)
    if not nq:
        return []
    qt = set(nq.split())
    out = []
    for e in entries:
        nt = norm(e["title"])
        if not nt:
            continue
        tt = set(nt.split())
        score = 0.0
        if nt == nq:
            score = 100
        elif nt.startswith(nq) or nq.startswith(nt):
            score = 80
        elif nq in norm(e["where"] + " " + e["title"]):
            score = 60
        else:
            common = len(qt & tt)
            if not common:
                continue
            score = 50.0 * common / max(len(qt), len(tt))
        if key and e.get("key") and e["key"].lower() == key.lower():
            score += 15
        if e["kind"] == "als":
            score += 5          # prefer sets that carry markers + tempo maps
        out.append((score, e))
    out.sort(key=lambda x: -x[0])
    return [dict(e, score=round(s)) for s, e in out[:limit]]


def _als_entry(path, root):
    title, key, bpm = parse_name(os.path.basename(path))
    t2, k2, b2 = parse_name(os.path.basename(os.path.dirname(path)))
    if not title or re.match(r"^(multi ?tracks?|untitled)$", title, re.I) or len(t2) > len(title):
        title = t2 or title
    return {"path": path, "kind": "als", "title": title, "key": key or k2, "bpm": bpm or b2, "where": _where(path, root)}


def _stems_entry(path, root, n):
    base = os.path.basename(path)
    title, key, bpm = parse_name(base)
    if not title or re.match(r"^(for )?(multi ?tracks?|stems|audio|imported|samples)$", base, re.I):
        p = os.path.dirname(path)
        while p and re.match(r"^(for )?(multi ?tracks?|stems|audio|imported|samples)$", os.path.basename(p), re.I):
            p = os.path.dirname(p)
        title, key, bpm = parse_name(os.path.basename(p))
    return {"path": path, "kind": "stems", "title": title, "key": key, "bpm": bpm, "where": _where(path, root), "n": n}


def _where(path, root):
    return os.path.relpath(path, root) if root and path.startswith(root) else path


def _audio_count(d):
    return len([f for f in _ls(d) if f.lower().endswith(AUDIO_EXT) and not f.startswith("._")])


def entry_for_path(path, root=""):
    """Describe a picked .als, stems folder, or whole song folder.
    For a song folder: its Ableton set(s) win; otherwise the subfolder holding the stems.
    Returns one entry, or {"choices": [...]} when the folder holds several sets."""
    path = path.rstrip("/")
    if path.lower().endswith(".als") and os.path.isfile(path):
        return _als_entry(path, root)
    if not os.path.isdir(path):
        raise ValueError("Pick an Ableton set (.als) or a song folder.")
    sets, stems = [], []
    base_depth = path.count(os.sep)
    for d, dirs, files in os.walk(path):
        depth = d.count(os.sep) - base_depth
        dirs[:] = sorted(x for x in dirs if not x.startswith(".") and x not in ("Backup", "Ableton Project Info")
                         and depth < 3)
        for f in sorted(files):
            if f.lower().endswith(".als") and not f.startswith("._"):
                sets.append(os.path.join(d, f))
        n = _audio_count(d)
        if n:
            stems.append((n, depth, d))
    if sets:
        if len(sets) == 1:
            return _als_entry(sets[0], root)
        return {"choices": [_als_entry(p, root) for p in sets]}
    if stems:
        # the folder with the most stems, preferring shallower folders on a tie
        n, _, d = sorted(stems, key=lambda x: (-x[0], x[1]))[0]
        return _stems_entry(d, root, n)
    raise ValueError("No Ableton set or audio files found in that folder.")


# ---- remembered picks: "when Planning Center says X, use this" ----

def _okey(title):
    return norm(title)


def load_overrides(path):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def remember(path, title, entry):
    data = load_overrides(path)
    data[_okey(title)] = entry
    with open(path, "w") as f:
        json.dump(data, f, indent=1)


def forget(path, title):
    data = load_overrides(path)
    data.pop(_okey(title), None)
    with open(path, "w") as f:
        json.dump(data, f, indent=1)


def match(entries, overrides, title, key=None, limit=6):
    """Best library matches for a Planning Center song, remembered pick first."""
    out = []
    o = overrides.get(_okey(title))
    if o and (o["path"].lower().endswith(".als") and os.path.isfile(o["path"]) or os.path.isdir(o["path"])):
        out.append(dict(o, score=999, remembered=True))
    for m in search(entries, title, key, limit=limit):
        if m["score"] >= 45 and not any(m["path"] == x["path"] for x in out):
            out.append(m)
    return out[:limit]
