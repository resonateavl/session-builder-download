"""Read a song from a MultiTracks / Loop Community / custom .als, or from a
plain folder of stems, into a neutral Song object the builder can place."""
import os
import re
import struct
import subprocess
import xml.etree.ElementTree as ET

from . import als

AUDIO_EXT = (".wav", ".aif", ".aiff", ".m4a", ".mp3", ".flac", ".caf")
SKIP_MIDI_TRACKS = ("REPEAT", "ADD LOCATORS", "LOCATORS")


class Clip:
    def __init__(self, **kw):
        self.name = ""
        self.path = ""
        self.start = 0.0          # arrangement start, song-relative beats
        self.end = 0.0
        self.loop_start = 0.0
        self.loop_end = 0.0
        self.start_relative = 0.0
        self.loop_on = False
        self.warped = True
        self.warp_mode = 0
        self.warp_markers = []    # [(sec, beat)]
        self.pitch_coarse = 0
        self.pitch_fine = 0
        self.gain = 1.0
        self.fade_in = 0.0
        self.fade_out = 0.0
        self.frames = 0
        self.sample_rate = 44100
        self.file_size = 0
        self.mtime = 0
        self.__dict__.update(kw)


class Stem:
    def __init__(self, name, clips, volume=1.0, on=True):
        self.name = name
        self.clips = clips
        self.volume = volume
        self.on = on
        self.family = None        # filled by classify()


class Song:
    def __init__(self):
        self.title = ""
        self.key = ""
        self.bpm = 0.0
        self.source = ""          # .als path or folder
        self.markers = []         # [(start, end, name)]
        self.locators = []        # [(time, name)]
        self.tempo = []           # [(time, bpm)] song-relative, first = initial
        self.sig = []             # [(time, enum)]
        self.stems = []
        self.length = 0.0
        self.warnings = []
        self.label_bpm = None     # BPM to show in the group name if different
        self.cues = []            # MIDI cue tracks: [{track, routing, color, clips:[{start,len,name,color,keytracks}]}]
        self.marker_source = ""

    def summary(self):
        return {
            "title": self.title, "key": self.key, "bpm": self.bpm,
            "source": self.source, "length_bars": round(self.length / 4, 1),
            "sections": [m[2] for m in self.markers],
            "stems": [s.name for s in self.stems], "warnings": self.warnings,
            "marker_source": self.marker_source,
            "cue_tracks": [c["track"] for c in self.cues],
        }


# ---------- names ----------

KEY_RE = re.compile(r"^([A-G](?:#|b|♯|♭)?m?)$")
BPM_RE = re.compile(r"(\d{2,3}(?:\.\d+)?)\s*(?:bpm|pbm)", re.I)


def parse_name(name):
    """'Bless The Lord-Album-C-129.00bpm' -> ('Bless The Lord', 'C', 129.0)."""
    base = re.sub(r"\.als$", "", name, flags=re.I)
    base = re.sub(r"\s*Project$", "", base)
    base = re.sub(r"^\[?multitracks?\]?\s*[-_]?\s*", "", base, flags=re.I)
    bpm = 0.0
    m = BPM_RE.search(base) or re.search(r"BPM\s*(\d{2,3}(?:\.\d+)?)", base, re.I)
    if m:
        bpm = float(m.group(1))
    key = ""
    m = re.search(r"\(([A-G](?:#|b)?m?)\)", base)
    if m:
        key = m.group(1)
    parts = [p.strip() for p in re.split(r"\s+-\s+|-|_|\[|\]", base) if p.strip()]
    if not key:
        for p in parts:
            if KEY_RE.match(p):
                key = p
    title_parts = []
    for p in parts:
        if KEY_RE.match(p) or BPM_RE.search(p) or re.match(r"^\d+(\.\d+)?$", p) or re.search(r"\bbpm\b", p, re.I):
            break
        title_parts.append(p)
    title = title_parts[0] if title_parts else base
    title = re.sub(r"\(([A-G](?:#|b)?m?)\)", "", title)
    title = re.sub(r"\s*\d{2,3}\s*bpm.*$", "", title, flags=re.I)
    title = re.sub(r"\s*\(?BPM\s*[\d.]+.*$", "", title, flags=re.I).strip()
    return title, key, bpm


# ---------- audio file info ----------

def audio_info(path):
    """-> (frames, sample_rate). Works for WAV/AIFF without dependencies,
    falls back to macOS afinfo or ffprobe for compressed formats."""
    try:
        with open(path, "rb") as f:
            head = f.read(12)
            if head[:4] == b"RIFF" and head[8:12] == b"WAVE":
                sr = ch = bits = None
                while True:
                    h = f.read(8)
                    if len(h) < 8:
                        break
                    cid, size = h[:4], struct.unpack("<I", h[4:])[0]
                    if cid == b"fmt ":
                        d = f.read(size)
                        ch, sr = struct.unpack("<HI", d[2:8])
                        bits = struct.unpack("<H", d[14:16])[0]
                        continue
                    if cid == b"data" and sr:
                        return size // (ch * bits // 8), sr
                    f.seek(size + (size & 1), 1)
            if head[:4] == b"FORM" and head[8:12] in (b"AIFF", b"AIFC"):
                while True:
                    h = f.read(8)
                    if len(h) < 8:
                        break
                    cid, size = h[:4], struct.unpack(">I", h[4:])[0]
                    if cid == b"COMM":
                        d = f.read(size)
                        frames = struct.unpack(">I", d[2:6])[0]
                        exp = struct.unpack(">H", d[8:10])[0] & 0x7FFF
                        mant = struct.unpack(">Q", d[10:18])[0]
                        sr = mant * 2.0 ** (exp - 16383 - 63)
                        return frames, int(round(sr))
                    f.seek(size + (size & 1), 1)
    except (OSError, struct.error):
        pass
    for cmd in (["afinfo", path], ["ffprobe", "-v", "error", "-select_streams", "a:0",
                                     "-show_entries", "stream=sample_rate,duration", "-of", "default=nw=1", path]):
        try:
            out = subprocess.run(cmd, capture_output=True, text=True, timeout=20).stdout
        except (OSError, subprocess.TimeoutExpired):
            continue
        sr = re.search(r"sample_rate=(\d+)|(\d+) Hz", out)
        dur = re.search(r"duration=([\d.]+)|estimated duration: ([\d.]+)", out)
        if sr and dur:
            sr = int(sr.group(1) or sr.group(2))
            return int(float(dur.group(1) or dur.group(2)) * sr), sr
    return 0, 44100


def _file_meta(path):
    try:
        st = os.stat(path)
        return st.st_size, st.st_mtime
    except OSError:
        return 0, 0


# ---------- reading from an .als ----------

def _file_index(root, depth=4):
    idx = {}
    root_depth = root.rstrip(os.sep).count(os.sep)
    for d, dirs, files in os.walk(root):
        if d.count(os.sep) - root_depth >= depth:
            dirs[:] = []
        dirs[:] = [x for x in dirs if not x.startswith(".") and x != "Backup"]
        for f in files:
            if f.lower().endswith(AUDIO_EXT) and not f.startswith("._"):
                idx.setdefault(f.lower(), os.path.join(d, f))
                idx.setdefault("~" + os.path.splitext(f)[0].lower(), os.path.join(d, f))
    return idx


def _fileref_candidates(fr, als_dir):
    """Paths the referenced sample might be at (Live 10/11/12 formats)."""
    out = []
    p = als.val(fr, "Path")
    rel = als.val(fr, "RelativePath")
    if p:
        out.append(p)
    if rel:
        out.append(os.path.join(als_dir, rel))
    # Live 10 style: <RelativePath><RelativePathElement Dir=".."/>...</RelativePath><Name/>
    rp = fr.find("RelativePath")
    name = als.val(fr, "Name")
    if rp is not None and len(rp) and name:
        parts = [e.get("Dir") for e in rp.findall("RelativePathElement")]
        out.append(os.path.join(als_dir, *[x for x in parts if x], name))
    base = os.path.basename(p or rel or name or "")
    return out, base


def song_from_als(path):
    tree = als.load(path)
    ls = tree.getroot().find("LiveSet")
    s = Song()
    s.source = path
    als_dir = os.path.dirname(path)
    folder = os.path.basename(als_dir)
    name = os.path.basename(path)
    t1, k1, b1 = parse_name(folder)
    t2, k2, b2 = parse_name(name)
    generic = re.match(r"^(multi ?tracks?|untitled|.*template.*)$", t2, re.I)
    s.title = t1 if generic or len(t1) > len(t2) else t2
    s.key = k2 or k1
    index = None
    search_root = als_dir
    if os.path.basename(als_dir).lower().endswith(" project"):
        search_root = os.path.dirname(als_dir)

    auto = als.read_master_automation(ls)
    tempo = auto["tempo"]
    sig = auto["sig"]

    markers, stems, cue_tracks = [], [], []
    for t in ls.find("Tracks"):
        nm = als.track_name(t)
        if t.tag == "MidiTrack":
            clips = []
            for c in t.findall("DeviceChain/MainSequencer/ClipTimeable/ArrangerAutomation/Events/MidiClip"):
                if als.val(c, "Disabled") == "true":
                    continue
                kts = c.find("Notes/KeyTracks")
                clips.append({"start": float(c.get("Time")), "len": float(als.val(c, "CurrentEnd")) - float(c.get("Time")),
                              "name": als.val(c, "Name", ""), "color": int(als.val(c, "Color", 23) or 23),
                              "keytracks": [ET.tostring(k, encoding="unicode") for k in kts] if kts is not None else []})
            if not clips:
                continue
            r = t.find("DeviceChain/MidiOutputRouting")
            cue_tracks.append({"track": nm, "color": int(als.val(t, "Color", 23) or 23),
                               "routing": {k: als.val(r, k, "") for k in ("Target", "UpperDisplayString", "LowerDisplayString")} if r is not None else None,
                               "clips": clips})
            if is_marker_track(nm):
                for c in clips:
                    markers.append((c["start"], c["start"] + c["len"], c["name"]))
            continue
        if t.tag != "AudioTrack":
            continue
        clips = []
        for c in t.findall("DeviceChain/MainSequencer/Sample/ArrangerAutomation/Events/AudioClip"):
            if als.val(c, "Disabled") == "true":
                continue
            fr = c.find("SampleRef/FileRef")
            cands, base = _fileref_candidates(fr, als_dir)
            found = next((x for x in cands if x and os.path.isfile(x)), None)
            if not found and base:
                if index is None:
                    index = _file_index(search_root)
                found = index.get(base.lower()) or index.get("~" + os.path.splitext(base)[0].lower())
            if not found:
                s.warnings.append("Missing audio for '%s': %s" % (nm, base))
                continue
            size, mtime = _file_meta(found)
            frames = als.val(c, "SampleRef/DefaultDuration")
            sr = als.val(c, "SampleRef/DefaultSampleRate")
            if not frames or frames == "0":
                frames, sr = audio_info(found)
            clips.append(Clip(
                name=als.val(c, "Name", nm), path=found,
                start=float(c.get("Time")), end=float(als.val(c, "CurrentEnd")),
                loop_start=float(als.val(c, "Loop/LoopStart", 0)),
                loop_end=float(als.val(c, "Loop/LoopEnd", 0)),
                start_relative=float(als.val(c, "Loop/StartRelative", 0)),
                loop_on=als.val(c, "Loop/LoopOn") == "true",
                warped=als.val(c, "IsWarped", "true") == "true",
                warp_mode=int(als.val(c, "WarpMode", 0)),
                warp_markers=[(float(w.get("SecTime")), float(w.get("BeatTime")))
                              for w in c.findall("WarpMarkers/WarpMarker")],
                pitch_coarse=float(als.val(c, "PitchCoarse", 0)),
                pitch_fine=float(als.val(c, "PitchFine", 0)),
                gain=float(als.val(c, "SampleVolume", 1)),
                fade_in=float(als.val(c, "Fades/FadeInLength", 0) or 0),
                fade_out=float(als.val(c, "Fades/FadeOutLength", 0) or 0),
                frames=int(float(frames)), sample_rate=int(float(sr or 44100)),
                file_size=size, mtime=mtime))
        if clips:
            stems.append(Stem(nm, clips,
                              volume=float(als.val(t, "DeviceChain/Mixer/Volume/Manual", 1)),
                              on=als.val(t, "DeviceChain/Mixer/Speaker/Manual", "true") == "true"))

    # Unwarped clips play at their recorded speed and their lengths are in seconds:
    # warp every one of them to the song's tempo so the grid, markers and the
    # next song all line up.
    unwarped = 0
    for st in stems:
        for c in st.clips:
            if not c.warped:
                warp_to_tempo(c, _tempo_at(tempo, c.start))
                unwarped += 1
    if unwarped:
        s.warnings.append("Warped %d unwarped clip%s to the song tempo." % (unwarped, "" if unwarped == 1 else "s"))

    locs = sorted((float(als.val(l, "Time")), als.val(l, "Name", ""))
                  for l in ls.find("Locators/Locators"))
    # song bounds
    starts = [m[0] for m in markers] + [c.start for st in stems for c in st.clips]
    ends = [m[1] for m in markers] + [c.end for st in stems for c in st.clips]
    if not starts:
        raise ValueError("No audio found in the Arrangement of %s (it may be in Session view, or the audio files "
                         "are missing). Use Change to pick another set or the stems folder." % os.path.basename(path))
    origin = min(starts)
    origin = origin - (origin % 4)          # snap to the bar
    if not markers and locs:
        pts = [l for l in locs if l[0] >= origin]
        for i, (t, n) in enumerate(pts):
            end = pts[i + 1][0] if i + 1 < len(pts) else max(ends)
            if end > t:
                markers.append((t, end, n.upper()))
    s.markers = [(a - origin, b - origin, n) for a, b, n in sorted(markers)]
    for ct in cue_tracks:
        for c in ct["clips"]:
            c["start"] -= origin
        ct["clips"] = [c for c in ct["clips"] if c["start"] > -16]
    s.cues = [ct for ct in cue_tracks if ct["clips"]]
    s.marker_source = "song's own set" if markers else ""
    names = [m[2] for m in s.markers]
    if names and sum(1 for n in names if re.match(r"^\s*(section|cue|marker|clip)?\s*\d*\s*$", n or "", re.I)) >= max(2, len(names) * 0.3):
        # placeholder markers (e.g. SECTION 1, 2...) - rebuild them from the guide instead
        s.markers, s.marker_source = [], ""
        s.cues = [ct for ct in s.cues if not is_marker_track(ct["track"])]
    s.locators = [(t - origin, n) for t, n in locs if t >= origin]
    for st in stems:
        for c in st.clips:
            c.start -= origin
            c.end -= origin
    s.stems = stems
    s.length = max(ends) - origin
    s.tempo = _shift_automation(tempo, origin)
    s.sig = _shift_automation(sig, origin)
    s.bpm = round(s.tempo[0][1], 2)
    name_bpm = b2 or b1
    if name_bpm and abs(name_bpm - s.bpm) > 0.5 and len(s.tempo) == 1:
        s.warnings.append("Set tempo is %g but the name says %g BPM - kept the set's tempo so the audio "
                          "plays at the right speed; check the grid." % (s.bpm, name_bpm))
        s.label_bpm = name_bpm
    return s


def _tempo_at(pts, t):
    v = pts[0][1] if pts else 120.0
    for pt, pv in sorted(pts):
        if pt <= t:
            v = pv
    return v or 120.0


def warp_to_tempo(c, bpm):
    """Turn an unwarped clip (loop points in seconds) into a warped one at bpm."""
    k = bpm / 60.0
    c.loop_start = c.loop_start * k
    c.loop_end = c.loop_end * k
    c.start_relative = c.start_relative * k
    length = c.loop_end - c.loop_start - c.start_relative
    if length <= 0 and c.frames and c.sample_rate:
        length = c.frames / float(c.sample_rate) * k
    c.end = c.start + length
    c.warped = True
    c.warp_markers = [(0.0, 0.0), (1.0 / k, 1.0)]


def _shift_automation(pts, origin):
    """Song-relative automation: value in force at origin first, then later changes."""
    pts = sorted(pts, key=lambda p: p[0])
    init = pts[0][1]
    later = []
    for t, v in pts:
        if t <= origin:
            init = v
        else:
            later.append((t - origin, v))
    return [(0.0, init)] + later


# ---------- reading from a bare stems folder ----------

def song_from_folder(folder, bpm=None, key=None, title=None):
    base = os.path.basename(folder.rstrip("/"))
    t, k, b = parse_name(base)
    if not t or re.match(r"^(for )?(multi ?tracks?|stems|audio|samples|imported)$", base.strip(), re.I):
        t, k2, b2 = parse_name(os.path.basename(os.path.dirname(folder.rstrip("/"))))
        k, b = k or k2, b or b2
    s = Song()
    s.source = folder
    s.title = title or t
    s.key = key or k
    s.bpm = float(bpm or b or 0)
    if not s.bpm:
        s.bpm = 120.0
        s.warnings.append("No BPM found in folder name; using 120. Set it in the app.")
    files = sorted(f for f in os.listdir(folder)
                   if f.lower().endswith(AUDIO_EXT) and not f.startswith("._"))
    seen = set()
    for f in files:
        stem_name = os.path.splitext(f)[0]
        if stem_name.lower() in seen:          # Bass.wav + Bass.m4a: keep one
            continue
        seen.add(stem_name.lower())
        p = os.path.join(folder, f)
        frames, sr = audio_info(p)
        secs = frames / float(sr) if sr else 0
        beats = secs * s.bpm / 60.0
        size, mtime = _file_meta(p)
        clip = Clip(name=stem_name, path=p, start=0.0, end=beats, loop_start=0.0,
                    loop_end=beats, warped=True, warp_mode=0,
                    warp_markers=[(0.0, 0.0), (60.0 / s.bpm, 1.0)],
                    frames=frames, sample_rate=sr, file_size=size, mtime=mtime)
        s.stems.append(Stem(stem_name, [clip]))
        s.length = max(s.length, beats)
    if not s.stems:
        raise ValueError("No audio files in %s" % folder)
    s.length = s.length + (-s.length % 4)
    s.markers = [(0.0, s.length, s.title.upper())]
    s.tempo = [(0.0, s.bpm)]
    s.sig = [(0.0, als.time_sig_value(4, 4))]
    s.warnings.append("No section markers (stems only) - one marker for the whole song.")
    return s


def load_song(path, **kw):
    if path.lower().endswith(".als"):
        return song_from_als(path)
    return song_from_folder(path, **kw)


def is_marker_track(name):
    n = name.upper()
    return any(k in n for k in ("MARKER", "SECTION", "CUES")) and not any(k in n for k in ("BAND", "REPEAT", "LOCATOR"))


def song_anchor(song):
    """Song-relative beat where the audio files' beat 0 sits (earliest stem)."""
    best = None
    for st in song.stems:
        for c in st.clips:
            if best is None or c.start < best[0]:
                best = (c.start, c.start - c.loop_start)
    return best[1] if best else 0.0


def apply_memory(song, rec):
    """Use the markers/cue tracks from one of the user's past sessions."""
    a = song_anchor(song)
    cues = []
    for t in rec["tracks"]:
        cues.append({"track": t["track"], "routing": t.get("routing"), "color": t.get("color", 23),
                     "clips": [{"start": a + c["rel"], "len": c["len"], "name": c["name"], "color": c["color"],
                                "keytracks": c.get("keytracks", [])} for c in t["clips"]]})
    mk = next((t for t in cues if is_marker_track(t["track"])), None)
    if mk:
        song.markers = [(c["start"], c["start"] + c["len"], c["name"]) for c in mk["clips"]]
    song.cues = cues
    song.marker_source = "your session: %s" % rec.get("session_name", "")
    song.warnings = [w for w in song.warnings if "No section markers" not in w]
