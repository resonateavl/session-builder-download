"""Planning Center Services: sign in (OAuth + PKCE), stay signed in (refresh
tokens), and read upcoming plans + songs for every connected church.

Tokens are stored on this Mac (not on the TRACKS drive) in
~/Library/Application Support/SessionBuilder/pco_accounts.json
"""
import base64
import hashlib
import json
import os
import secrets
import ssl
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = os.environ.get("SB_PCO_BASE", "https://api.planningcenteronline.com")
API = BASE + "/services/v2"
SCOPES = "services people"
STORE_DIR = os.environ.get("SB_STORE_DIR", os.path.expanduser("~/Library/Application Support/SessionBuilder"))
STORE = os.path.join(STORE_DIR, "pco_accounts.json")
_lock = threading.Lock()
_pending = {}   # state -> (verifier, redirect_uri, created)


# ---------- token store ----------

def _load():
    try:
        with open(STORE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {"accounts": []}


def _save(data):
    os.makedirs(STORE_DIR, exist_ok=True)
    tmp = STORE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    os.chmod(tmp, 0o600)
    os.replace(tmp, STORE)


def accounts():
    """Connected churches, without secrets."""
    return [{k: a.get(k) for k in ("id", "org_name", "person_name", "kind", "connected_at", "output_dir")}
            for a in _load()["accounts"]]


def set_output_dir(acc_id, path):
    with _lock:
        d = _load()
        for a in d["accounts"]:
            if a["id"] == acc_id:
                a["output_dir"] = path.strip()
        _save(d)


def output_dir_for(acc_id):
    a = next((a for a in _load()["accounts"] if a["id"] == acc_id), None)
    return (a or {}).get("output_dir") or ""


def remove_account(acc_id):
    with _lock:
        d = _load()
        d["accounts"] = [a for a in d["accounts"] if a["id"] != acc_id]
        _save(d)


# ---------- HTTP ----------

_CTX = None


def _ssl_context():
    """Verified HTTPS that works with python.org's Python on macOS, which ships
    without trusted root certificates until 'Install Certificates' is run.
    Falls back to the Mac's own system root certificates. Never disables checks."""
    global _CTX
    if _CTX is not None:
        return _CTX
    ctx = ssl.create_default_context()
    if not ctx.cert_store_stats().get("x509_ca"):
        loaded = False
        try:
            import certifi
            ctx.load_verify_locations(certifi.where())
            loaded = True
        except Exception:
            pass
        if not loaded:
            pems = []
            for kc in ("/System/Library/Keychains/SystemRootCertificates.keychain",
                       "/Library/Keychains/System.keychain"):
                try:
                    out = subprocess.run(["/usr/bin/security", "find-certificate", "-a", "-p", kc],
                                         capture_output=True, text=True, timeout=30).stdout
                    if "BEGIN CERTIFICATE" in out:
                        pems.append(out)
                except Exception:
                    pass
            if pems:
                ctx.load_verify_locations(cadata="\n".join(pems))
    _CTX = ctx
    return ctx


def _post_form(url, fields):
    body = urllib.parse.urlencode(fields).encode()
    req = urllib.request.Request(url, data=body, headers={"User-Agent": "SessionBuilder",
                                                          "Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=30, context=_ssl_context()) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        raise RuntimeError("Planning Center said: %s %s" % (e.code, e.read().decode()[:300]))


def _get(url, auth):
    req = urllib.request.Request(url, headers={"Authorization": auth, "User-Agent": "SessionBuilder"})
    with urllib.request.urlopen(req, timeout=30, context=_ssl_context()) as r:
        return json.loads(r.read().decode())


# ---------- OAuth sign-in ----------

def login_url(client_id, redirect_uri):
    verifier = secrets.token_urlsafe(48)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
    state = secrets.token_urlsafe(16)
    _pending[state] = (verifier, redirect_uri, time.time())
    q = urllib.parse.urlencode({
        "client_id": client_id, "redirect_uri": redirect_uri, "response_type": "code",
        "scope": SCOPES, "state": state, "prompt": "select_account", "code_challenge": challenge, "code_challenge_method": "S256",
    })
    return BASE + "/oauth/authorize?" + q


def finish_login(client_id, client_secret, code, state):
    if state not in _pending:
        raise RuntimeError("This sign-in link expired. Start again from Session Builder.")
    verifier, redirect_uri, _ = _pending.pop(state)
    tok = _post_form(BASE + "/oauth/token", {
        "grant_type": "authorization_code", "code": code, "client_id": client_id,
        "client_secret": client_secret, "redirect_uri": redirect_uri, "code_verifier": verifier,
    })
    acc = {"kind": "oauth", "access_token": tok["access_token"], "refresh_token": tok.get("refresh_token"),
           "expires_at": time.time() + int(tok.get("expires_in", 7200)), "connected_at": time.strftime("%Y-%m-%d")}
    auth = "Bearer " + acc["access_token"]
    _fill_identity(acc, auth)
    with _lock:
        d = _load()
        d["accounts"] = [a for a in d["accounts"] if a["id"] != acc["id"]] + [acc]
        _save(d)
    return acc["org_name"]


def add_token_account(app_id, secret):
    """Personal Access Token alternative (one church, never expires)."""
    acc = {"kind": "pat", "app_id": app_id, "secret": secret, "connected_at": time.strftime("%Y-%m-%d")}
    _fill_identity(acc, _basic(app_id, secret))
    with _lock:
        d = _load()
        d["accounts"] = [a for a in d["accounts"] if a["id"] != acc["id"]] + [acc]
        _save(d)
    return acc["org_name"]


def _basic(app_id, secret):
    return "Basic " + base64.b64encode(("%s:%s" % (app_id, secret)).encode()).decode()


def _fill_identity(acc, auth):
    org = _get(API, auth)["data"]
    acc["org_id"] = org["id"]
    acc["org_name"] = org["attributes"].get("name") or "Church %s" % org["id"]
    try:
        me = _get(BASE + "/people/v2/me", auth)["data"]
        acc["person_id"] = me["id"]
        acc["person_name"] = me["attributes"].get("name")
    except Exception:
        acc["person_id"] = ""
        acc["person_name"] = ""
    acc["id"] = "%s-%s" % (acc["org_id"], acc["person_id"])


def _auth_for(acc_id, client_id, client_secret):
    """Valid Authorization header for an account, refreshing the token if needed."""
    with _lock:
        d = _load()
        acc = next((a for a in d["accounts"] if a["id"] == acc_id), None)
        if acc is None:
            raise RuntimeError("That church is no longer connected.")
        if acc["kind"] == "pat":
            return _basic(acc["app_id"], acc["secret"])
        if time.time() > acc["expires_at"] - 300:
            try:
                tok = _post_form(BASE + "/oauth/token", {
                    "grant_type": "refresh_token", "refresh_token": acc["refresh_token"],
                    "client_id": client_id, "client_secret": client_secret,
                })
            except RuntimeError:
                acc["needs_login"] = True
                _save(d)
                raise RuntimeError("Planning Center sign-in for %s expired. Click Sign in again." % acc["org_name"])
            acc["access_token"] = tok["access_token"]
            acc["refresh_token"] = tok.get("refresh_token", acc["refresh_token"])
            acc["expires_at"] = time.time() + int(tok.get("expires_in", 7200))
            acc.pop("needs_login", None)
            _save(d)
        return "Bearer " + acc["access_token"]


def refresh_all(client_id, client_secret):
    """Renew every church's sign-in (Planning Center drops a sign-in that goes
    90 days without a renewal), so opening the app keeps them all alive."""
    for acc in _load()["accounts"]:
        if acc["kind"] != "oauth":
            continue
        try:
            with _lock:
                d = _load()
                for a in d["accounts"]:
                    if a["id"] == acc["id"]:
                        a["expires_at"] = 0     # force a renewal
                _save(d)
            _auth_for(acc["id"], client_id, client_secret)
        except Exception:
            pass


# ---------- Services data ----------

def upcoming_plans(client_id, client_secret, when="future", months=3, max_per_type=200):
    """Every plan within `months` from today (future) or back in time (past), all pages."""
    import datetime
    today = datetime.date.today()
    limit = today + datetime.timedelta(days=int(31 * months)) if when != "past" \
        else today - datetime.timedelta(days=int(31 * months))
    out, errors = [], []
    for acc in _load()["accounts"]:
        try:
            auth = _auth_for(acc["id"], client_id, client_secret)
            for st in _get(API + "/service_types?per_page=100", auth)["data"]:
                order = "sort_date" if when != "past" else "-sort_date"
                url = API + "/service_types/%s/plans?filter=%s&order=%s&per_page=50" % (
                    st["id"], "past" if when == "past" else "future", order)
                n, done = 0, False
                while url and not done and n < max_per_type:
                    page = _get(url, auth)
                    for p in page["data"]:
                        a = p["attributes"]
                        d = (a.get("sort_date") or "")[:10]
                        if d:
                            dd = datetime.date.fromisoformat(d)
                            if (when != "past" and dd > limit) or (when == "past" and dd < limit):
                                done = True
                                break
                        n += 1
                        out.append({"account": acc["id"], "church": acc["org_name"],
                                    "service_type_id": st["id"], "service_type": st["attributes"]["name"],
                                    "plan_id": p["id"], "date": a.get("sort_date") or "",
                                    "dates": a.get("dates"), "title": a.get("title") or "",
                                    "series": a.get("series_title") or "", "items": a.get("items_count"),
                                    "songs": None, "people": a.get("needed_positions_count")})
                    url = (page.get("links") or {}).get("next")
        except Exception as e:
            errors.append("%s: %s" % (acc.get("org_name"), e))
    out.sort(key=lambda x: x["date"], reverse=(when == "past"))
    return {"plans": out, "errors": errors}


def plan_detail(acc_id, service_type_id, plan_id, client_id, client_secret):
    """Full order of service: every item, songs with key/BPM/arrangement/sequence."""
    auth = _auth_for(acc_id, client_id, client_secret)
    data = _get(API + "/service_types/%s/plans/%s/items?include=song,arrangement,key&per_page=100"
                % (service_type_id, plan_id), auth)
    inc = {(i["type"], i["id"]): i["attributes"] for i in data.get("included", [])}
    items = []
    for it in data["data"]:
        a = it["attributes"]
        rel = it.get("relationships", {})

        def attr(kind):
            d = (rel.get(kind) or {}).get("data")
            return inc.get((d["type"], d["id"]), {}) if d else {}
        row = {"type": a.get("item_type") or "item", "title": a.get("title") or "",
               "length": a.get("length") or 0, "description": a.get("description") or ""}
        if row["type"] == "song":
            song, arr, key = attr("song"), attr("arrangement"), attr("key")
            row.update({
                "title": song.get("title") or row["title"], "author": song.get("author") or "",
                "key": a.get("key_name") or key.get("starting_key") or "",
                "bpm": arr.get("bpm") or 0, "meter": arr.get("meter") or "",
                "arrangement": arr.get("name") or "",
                "sequence": arr.get("sequence_short") or arr.get("sequence") or [],
            })
        items.append(row)
    return items


def plan_songs(acc_id, service_type_id, plan_id, client_id, client_secret):
    auth = _auth_for(acc_id, client_id, client_secret)
    data = _get(API + "/service_types/%s/plans/%s/items?include=song,arrangement,key&per_page=100"
                % (service_type_id, plan_id), auth)
    inc = {(i["type"], i["id"]): i["attributes"] for i in data.get("included", [])}
    songs = []
    for it in data["data"]:
        a = it["attributes"]
        if a.get("item_type") != "song":
            continue
        rel = it.get("relationships", {})

        def attr(kind):
            d = (rel.get(kind) or {}).get("data")
            return inc.get((d["type"], d["id"]), {}) if d else {}
        song, arr, key = attr("song"), attr("arrangement"), attr("key")
        songs.append({
            "title": song.get("title") or a.get("title"),
            "key": a.get("key_name") or key.get("starting_key") or "",
            "bpm": arr.get("bpm") or 0,
            "arrangement": arr.get("name") or "",
            "sequence": arr.get("sequence_short") or arr.get("sequence") or [],
        })
    return songs
