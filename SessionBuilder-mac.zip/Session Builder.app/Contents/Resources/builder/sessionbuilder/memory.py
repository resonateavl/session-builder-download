"""Learn the MIDI markers and cue tracks you placed in your own past sessions,
so a song you've done before comes back with *your* cues.

For every past set that has song groups ("1-SONG-KEY-BPM") we record, per song:
  - every clip on every un-grouped MIDI track (MARKERS, REPEAT, STOP, ADD LOCATORS,
    BAND MARKERS, ...) that falls inside the song, with its notes, relative to the
    point in the song's audio where the file starts (so it lines up again later)
  - each cue track's MIDI output routing (e.g. IAC Driver Bus 1, Ch. 1)
"""
import gzip
import json
import os
import re
import time
import xml.etree.ElementTree as ET

from . import als
from .library import norm
from .songs import parse_name

GROUP_RE = re.compile(r"^\s*\d+\s*-\s*\S")
SKIP_DIRS = {"Backup", "Samples", "Ableton Project Info", "Session Builder", "Waves",
             "LA Scoring Strings", "System Volume Information", "MultiTracks", "Imported", "Processed"}


def song_title_from_group(name):
    s = re.sub(r"^\s*\d+\s*-\s*", "", name)
    parts = [p.strip() for p in s.split("-")]
    title = parts[0]
    key = ""
    bpm = 0.0
    for p in parts[1:]:
        if re.match(r"^[A-G](#|b)?m?$", p, re.I) and not key:
            key = p
        elif re.match(r"^\d{2,3}(\.\d+)?$", p):
            bpm = float(p)
    return title, key, bpm


def _clip_anchor(c):
    """Arrangement beat where the audio file's beat 0 sits for this clip."""
    return float(c.get("Time")) - float(als.val(c, "Loop/LoopStart", 0) or 0)


def learn_session(path):
    """-> list of song records from one past session (empty if it isn't one)."""
    try:
        with open(path, "rb") as f:
            data = f.read()
        if data[:2] == b"\x1f\x8b":
            data = gzip.decompress(data)
    except OSError:
        return []
    if b"<GroupTrack" not in data or b"<MidiTrack" not in data:
        return []
    try:
        ls = ET.fromstring(data).find("LiveSet")
    except ET.ParseError:
        return []
    tracks = list(ls.find("Tracks"))
    by_id = {t.get("Id"): t for t in tracks}
    groups = [t for t in tracks if t.tag == "GroupTrack" and GROUP_RE.match(als.track_name(t))]
    if not groups:
        return []

    # song spans from the audio clips inside each group (nested groups included)
    def root_group(t):
        seen = 0
        while t is not None and seen < 10:
            g = als.val(t, "TrackGroupId", "-1")
            if g == "-1":
                return t
            t = by_id.get(g)
            seen += 1
        return t

    spans = {}
    for t in tracks:
        if t.tag != "AudioTrack":
            continue
        g = root_group(t)
        if g is None or g not in groups:
            continue
        for c in t.findall("DeviceChain/MainSequencer/Sample/ArrangerAutomation/Events/AudioClip"):
            if als.val(c, "Disabled") == "true":
                continue
            st, en = float(c.get("Time")), float(als.val(c, "CurrentEnd"))
            fname = os.path.basename(als.val(c, "SampleRef/FileRef/Path", "") or als.val(c, "SampleRef/FileRef/RelativePath", "") or "")
            sp = spans.setdefault(g.get("Id"), {"start": st, "end": en, "anchor": _clip_anchor(c), "files": set()})
            if st < sp["start"]:
                sp["start"], sp["anchor"] = st, _clip_anchor(c)
            sp["end"] = max(sp["end"], en)
            if fname:
                sp["files"].add(fname.lower())
    songs = sorted(((spans[g.get("Id")]["start"], g) for g in groups if g.get("Id") in spans), key=lambda x: x[0])
    if not songs:
        return []

    cue_tracks = [t for t in tracks if t.tag == "MidiTrack" and als.val(t, "TrackGroupId", "-1") == "-1"]
    starts = [st for st, _ in songs]

    def owner(cs, name=""):
        # the song that starts at or just after (count-ins sit up to 2 bars early) this clip;
        # STOP/END cues belong to the song they end.
        early = -8.0 if re.search(r"stop|end|fin\b|final", name, re.I) else 8.001
        j = None
        for k, st in enumerate(starts):
            if st <= cs + early:
                j = k
        if j is None and cs >= starts[0] - 16:
            j = 0
        return j

    per_song = [dict() for _ in songs]
    routing = {}
    for t in cue_tracks:
        tn = als.track_name(t)
        r = t.find("DeviceChain/MidiOutputRouting")
        routing[tn] = ({k: als.val(r, k, "") for k in ("Target", "UpperDisplayString", "LowerDisplayString")}
                       if r is not None else None, int(als.val(t, "Color", 23) or 23))
        for c in t.findall("DeviceChain/MainSequencer/ClipTimeable/ArrangerAutomation/Events/MidiClip"):
            if als.val(c, "Disabled") == "true":
                continue
            cs = float(c.get("Time"))
            j = owner(cs, als.val(c, "Name", "") + " " + tn)
            if j is None:
                continue
            sp = spans[songs[j][1].get("Id")]
            if cs > sp["end"] + 32:
                continue
            kts = c.find("Notes/KeyTracks")
            per_song[j].setdefault(tn, []).append({
                "rel": cs - sp["anchor"], "len": float(als.val(c, "CurrentEnd")) - cs,
                "name": als.val(c, "Name", ""), "color": int(als.val(c, "Color", 23) or 23),
                "keytracks": [ET.tostring(k, encoding="unicode") for k in kts] if kts is not None else [],
            })
    mtime = os.path.getmtime(path)
    out = []
    for i, (start, g) in enumerate(songs):
        sp = spans[g.get("Id")]
        tracks_out = [{"track": tn, "routing": routing[tn][0], "color": routing[tn][1],
                       "clips": sorted(cl, key=lambda x: x["rel"])} for tn, cl in per_song[i].items()]
        if not tracks_out:
            continue
        title, key, bpm = song_title_from_group(als.track_name(g))
        out.append({"title": title, "key": key, "bpm": bpm, "group": als.track_name(g),
                    "session": path, "session_name": os.path.splitext(os.path.basename(path))[0],
                    "mtime": mtime, "files": sorted(sp["files"])[:60], "tracks": tracks_out})
    return out


def scan(roots, cache_path, log=print):
    """Learn from every session under the given folders. Re-reads only changed files."""
    cache = {}
    try:
        with open(cache_path) as f:
            cache = json.load(f).get("files", {})
    except (OSError, ValueError):
        pass
    files, t0 = {}, time.time()
    for root in roots:
        if not os.path.isdir(root):
            continue
        for d, dirs, fs in os.walk(root):
            dirs[:] = [x for x in dirs if not x.startswith(".") and x not in SKIP_DIRS]
            for f in fs:
                if not f.lower().endswith(".als") or f.startswith("._"):
                    continue
                p = os.path.join(d, f)
                try:
                    m = os.path.getmtime(p)
                except OSError:
                    continue
                c = cache.get(p)
                files[p] = c if c and c.get("mtime") == m else {"mtime": m, "songs": learn_session(p)}
    with open(cache_path, "w") as f:
        json.dump({"time": time.time(), "files": files}, f)
    n = sum(len(v["songs"]) for v in files.values())
    log("Learned markers for %d song uses from %d sessions in %.0fs"
        % (n, sum(1 for v in files.values() if v["songs"]), time.time() - t0))
    return files


def load(cache_path):
    try:
        with open(cache_path) as f:
            return json.load(f).get("files", {})
    except (OSError, ValueError):
        return {}


GENERIC = re.compile(r"^\s*(section|cue|marker|clip|midi clip)?\s*\d*\s*$", re.I)


def is_generic(rec):
    """True for markers Session Builder made as placeholders (SECTION 1, 2...) - not yours."""
    names = [c["name"] for t in rec["tracks"] if any(k in t["track"].upper() for k in ("MARKER", "SECTION", "CUES"))
             for c in t["clips"]]
    if not names:
        return False
    generic = sum(1 for n in names if GENERIC.match(n or ""))
    return generic >= max(2, len(names) * 0.3)


def find(files, title, key=None, stem_files=None, exclude=None):
    """Most recent session record for this song (same key and shared audio files rank higher)."""
    nt = norm(title)
    if not nt:
        return None
    best, best_score = None, -1
    stem_files = {f.lower() for f in (stem_files or [])}
    for path, v in files.items():
        if exclude and path == exclude:
            continue
        for r in v["songs"]:
            if is_generic(r):
                continue
            rt = norm(r["title"])
            if rt != nt and not (len(nt) > 5 and (rt.startswith(nt) or nt.startswith(rt))):
                continue
            score = 10 if rt == nt else 5
            if key and r["key"] and r["key"].lower() == key.lower():
                score += 5
            if stem_files and stem_files & set(r["files"]):
                score += 8
            score += r["mtime"] / 1e10          # newest wins ties
            if score > best_score:
                best, best_score = r, score
    return best
