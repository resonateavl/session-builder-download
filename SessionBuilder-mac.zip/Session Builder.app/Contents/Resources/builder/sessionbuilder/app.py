"""Local web app: python3 -m sessionbuilder.app  -> http://localhost:8765"""
import datetime
import json
import os
import sys
import threading
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import builder, library
from .als import ROOT_DIR, DATA_DIR
from .songs import load_song

PORT = 8765
VERSION = "Nov 15 · app 1.2"
SETTINGS_PATH = os.path.join(DATA_DIR, "settings.json")
INDEX_PATH = os.path.join(DATA_DIR, "library_index.json")
OVERRIDES_PATH = os.path.join(DATA_DIR, "song_picks.json")
MEMORY_PATH = os.path.join(DATA_DIR, "marker_memory.json")
CUE_LEARNED_PATH = os.path.join(DATA_DIR, "cue_words_learned_v3.json")
from . import cues as _cues
_cues.TEMPLATE_FILES = [os.path.join(ROOT_DIR, "resources", "cue_templates.json"), CUE_LEARNED_PATH]


def learn_cue_words(max_songs=150, budget=900):
    """Collect more examples of spoken cue words from library songs that have markers."""
    import json, time
    from .builder import classify as fam, standard_name, load_config
    try:
        with open(CUE_LEARNED_PATH) as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {"done": [], "examples": []}
    done = set(data["done"])
    cfg, t0, n = load_config(), time.time(), 0
    for e in entries():
        if e["kind"] != "als" or e["path"] in done:
            continue
        if n >= max_songs or time.time() - t0 > budget:
            break
        done.add(e["path"])
        n += 1
        try:
            sg = load_song(e["path"])
            if not sg.marker_source or len(sg.markers) < 4:
                continue
            g = [x for x in sg.stems if fam(standard_name(x.name, sg.title, cfg), cfg) == "guide" and "vocal" not in x.name.lower()]
            if g:
                data["examples"] += [[lab, [round(v, 3) for v in vec]]
                                     for lab, vec in _cues.harvest_song(sg, [c for x in g for c in x.clips])]
        except Exception:
            continue
    # keep the file small: at most 150 examples of each word (newest kept)
    per = {}
    for ex in reversed(data["examples"]):
        per.setdefault(ex[0], [])
        if len(per[ex[0]]) < 150:
            per[ex[0]].append([ex[0], [round(v, 3) for v in ex[1]]])
    data["examples"] = [e for v in per.values() for e in v]
    data["done"] = sorted(done)
    with open(CUE_LEARNED_PATH, "w") as f:
        json.dump(data, f, separators=(",", ":"))
    _cues.reset_templates()
MEM = {"files": None, "scanning": False, "msg": ""}


def session_roots():
    return [settings()["library_root"], os.path.expanduser("~/Music")]


def learn_sessions():
    from . import memory
    if MEM["scanning"]:
        return
    MEM["scanning"] = True
    try:
        MEM["files"] = memory.scan(session_roots(), MEMORY_PATH, log=lambda m: MEM.update(msg=m))
    except Exception as e:
        MEM["msg"] = "Couldn't read past sessions: %s" % e
    finally:
        MEM["scanning"] = False


def memory_files():
    from . import memory
    if MEM["files"] is None:
        MEM["files"] = memory.load(MEMORY_PATH)
    return MEM["files"]
DEFAULTS = {
    "library_root": "/Volumes/TRACKS" if os.path.isdir("/Volumes/TRACKS") else os.path.expanduser("~/Music"),
    "template": os.path.join(ROOT_DIR, "templates", "TRACKS_W_LOOPS.als"),
    "output_dir": "/Volumes/TRACKS/Multitracks/Services/FPCGH" if os.path.isdir("/Volumes/TRACKS/Multitracks")
                  else os.path.expanduser("~/Music/Session Builder Sets"),
    "gap_bars": 0,
    "copy_audio": False,
    "pco_client_id": "",
    "pco_client_secret": "",
}
REDIRECT = "http://localhost:%d/pco/callback" % PORT
STATE = {"entries": None, "lock": threading.Lock()}


def default_out_dir(body, s):
    """Church folder (or default) + year + MONTH."""
    out_dir = s["output_dir"]
    if body.get("account"):
        from . import pco
        out_dir = pco.output_dir_for(body["account"]) or out_dir
    d = datetime.date.today()
    try:
        d = datetime.datetime.strptime(body.get("date", ""), "%Y-%m-%d").date()
    except ValueError:
        pass
    return os.path.join(out_dir, str(d.year), d.strftime("%B").upper())


def settings():
    s = dict(DEFAULTS)
    if os.path.exists(SETTINGS_PATH):
        with open(SETTINGS_PATH) as f:
            s.update(json.load(f))
    # The app was moved (e.g. Downloads -> Applications): fall back to the bundled template.
    if not os.path.exists(s.get("template") or ""):
        s["template"] = DEFAULTS["template"]
    return s


def save_settings(new):
    s = settings()
    s.update({k: v for k, v in new.items() if k in DEFAULTS})
    with open(SETTINGS_PATH, "w") as f:
        json.dump(s, f, indent=2)
    return s


def entries(rescan=False):
    with STATE["lock"]:
        if STATE["entries"] is None or rescan:
            STATE["entries"] = library.load_index(settings()["library_root"], INDEX_PATH, rescan=rescan)
        return STATE["entries"]


def api(path, q, body):
    if path in ("/api/build", "/api/append"):
        LIFE["busy"] += 1
        try:
            return _api(path, q, body)
        finally:
            LIFE["busy"] -= 1
    return _api(path, q, body)


def _api(path, q, body):
    s = settings()
    if path == "/api/settings":
        if body is not None:
            out = save_settings(body)
            migrate_pat_keys()
            return out
        out = dict(s)
        out["pco_client_secret"] = "********" if s["pco_client_secret"] else ""
        out["redirect_uri"] = REDIRECT
        out["version"] = VERSION
        return out
    if path == "/api/search":
        return library.search(entries(), q.get("q", [""])[0], q.get("key", [None])[0])
    if path == "/api/rescan":
        n = len(entries(rescan=True))
        learn_sessions()
        return {"count": n, "memory": MEM["msg"]}
    if path == "/api/match_lines":
        import re as _re
        idx = entries()
        picks = library.load_overrides(OVERRIDES_PATH)
        out = []
        for line in (body.get("text") or "").splitlines():
            line = _re.sub(r"^\s*(\d+[.)]\s*|[-*•]\s*)", "", line).strip()
            if not line:
                continue
            title, key = line, ""
            m = _re.match(r"^(.*?)\s*(?:[-–|(]\s*|\s+in\s+)([A-G](?:#|b)?m?)\s*\)?$", line)
            if m:
                title, key = m.group(1).strip(), m.group(2)
            out.append({"title": title, "key": key, "matches": library.match(idx, picks, title, key or None)})
        return out
    if path == "/api/search_all":
        return library.search(entries(), q.get("q", [""])[0], limit=40)
    if path == "/api/ping":
        import time
        LIFE["last_ping"] = time.time()
        return {"ok": True, "version": VERSION}
    if path == "/api/quit":
        threading.Timer(0.4, lambda: SERVER["srv"].shutdown() if SERVER.get("srv") else os._exit(0)).start()
        return {"ok": True}
    if path == "/api/default_out":
        return {"folder": default_out_dir(body, s)}
    if path == "/api/reveal":
        import subprocess
        subprocess.run(["open", "-R", body["path"]], timeout=20)
        return {"ok": True}
    if path == "/api/pick" and body.get("what") == "session":
        import subprocess
        start = s["output_dir"] if os.path.isdir(s["output_dir"]) else os.path.expanduser("~")
        script = ('POSIX path of (choose file with prompt "Pick the session to add these songs to" '
                  'of type {"als", "com.ableton.live-set"} default location (POSIX file "%s"))' % start)
        r = subprocess.run(["osascript", "-e", 'tell application "System Events" to activate', "-e", script],
                           capture_output=True, text=True, timeout=600)
        if r.returncode != 0 or not r.stdout.strip():
            return {"cancelled": True}
        return {"session": r.stdout.strip()}
    if path == "/api/pick" and body.get("what") == "save":
        import subprocess
        start = body.get("start") or s["output_dir"]
        while start and not os.path.isdir(start):
            start = os.path.dirname(start)
        start = start or os.path.expanduser("~")
        script = ('POSIX path of (choose folder with prompt "Where should this session be saved? '
                  '(a \\"%s Project\\" folder is made inside)" default location (POSIX file "%s"))'
                  % (body.get("name", "SUNDAY").replace('"', ""), start))
        r = subprocess.run(["osascript", "-e", 'tell application "System Events" to activate', "-e", script],
                           capture_output=True, text=True, timeout=600)
        if r.returncode != 0 or not r.stdout.strip():
            return {"cancelled": True}
        return {"folder": r.stdout.strip().rstrip("/")}
    if path == "/api/pick":
        import subprocess
        what = body.get("what", "file")
        start = s["library_root"] if os.path.isdir(s["library_root"]) else os.path.expanduser("~")
        if what == "folder":
            script = 'POSIX path of (choose folder with prompt "Pick the song folder (it will use the Ableton set inside, or the stems)" default location (POSIX file "%s"))' % start
        else:
            script = 'POSIX path of (choose file with prompt "Pick the song\'s Ableton set (.als)" of type {"als", "com.ableton.live-set"} default location (POSIX file "%s"))' % start
        r = subprocess.run(["osascript", "-e", 'tell application "System Events" to activate', "-e", script],
                           capture_output=True, text=True, timeout=600)
        if r.returncode != 0 or not r.stdout.strip():
            return {"cancelled": True}
        return library.entry_for_path(r.stdout.strip(), s["library_root"])
    if path == "/api/entry":
        return library.entry_for_path(body["path"].strip(), s["library_root"])
    if path == "/api/remember":
        if body.get("forget"):
            library.forget(OVERRIDES_PATH, body["title"])
        else:
            e = {k: body["entry"].get(k) for k in ("path", "kind", "title", "key", "bpm", "where")}
            library.remember(OVERRIDES_PATH, body["title"], e)
        return {"ok": True}
    if path == "/api/song":
        from . import memory
        from .songs import apply_memory
        sg = load_song(body["path"])
        if body.get("title"):
            sg.title = body["title"]
        rec = memory.find(memory_files(), sg.title, body.get("key") or sg.key,
                          [os.path.basename(c.path) for st in sg.stems for c in st.clips])
        if rec:
            apply_memory(sg, rec)
        out = sg.summary()
        out["sections"] = [m[2] for m in sg.markers]
        return out
    if path.startswith("/api/pco/"):
        from . import pco
        cid, csec = s["pco_client_id"], s["pco_client_secret"]
        if path == "/api/pco/accounts":
            if body and body.get("remove"):
                pco.remove_account(body["remove"])
            if body and body.get("set_folder"):
                pco.set_output_dir(body["set_folder"], body.get("folder", ""))
            out = {"accounts": pco.accounts(), "oauth_ready": bool(cid and csec), "status": PCO_STATUS["msg"]}
            PCO_STATUS["msg"] = ""
            return out
        if path == "/api/pco/token":
            try:
                return {"church": pco.add_token_account(body["app_id"].strip(), body["secret"].strip())}
            except Exception as e:
                if "401" in str(e):
                    raise ValueError("Planning Center didn't accept that token. Check the Application ID and Secret.")
                raise
        if not pco.accounts():
            raise ValueError("Sign in to Planning Center first (Settings → Planning Center).")
        if path == "/api/pco/plans":
            return pco.upcoming_plans(cid, csec, when=q.get("when", ["future"])[0],
                                      months=float(q.get("months", ["3"])[0]))
        if path == "/api/pco/plan":
            items = pco.plan_detail(body["account"], body["service_type_id"], body["plan_id"], cid, csec)
            idx = entries()
            for it in items:
                if it["type"] == "song":
                    it["matches"] = library.match(idx, library.load_overrides(OVERRIDES_PATH), it["title"], it["key"])
            return items
        if path == "/api/pco/songs":
            songs = pco.plan_songs(body["account"], body["service_type_id"], body["plan_id"], cid, csec)
            idx = entries()
            for sg in songs:
                sg["matches"] = library.match(idx, library.load_overrides(OVERRIDES_PATH), sg["title"], sg["key"])
            return songs
    if path == "/api/append":
        import shutil, time as _t
        target = body["session"]
        if not (target.lower().endswith(".als") and os.path.isfile(target)):
            raise ValueError("Pick an Ableton set (.als) to add the songs to.")
        bdir = os.path.join(os.path.dirname(target), "Backup")
        os.makedirs(bdir, exist_ok=True)
        stem = os.path.splitext(os.path.basename(target))[0]
        backup = os.path.join(bdir, "%s [before added songs %s].als" % (stem, _t.strftime("%Y-%m-%d %H%M%S")))
        shutil.copy2(target, backup)
        log = []
        builder.build_set(target, body["songs"], target, append=True,
                          gap_bars=int(body.get("gap_bars", s["gap_bars"])),
                          copy_audio=bool(body.get("copy_audio", s["copy_audio"])),
                          log=log.append, memory_files=memory_files())
        log.append("Backup of the original: " + backup)
        return {"path": target, "log": log, "backup": backup}
    if path == "/api/build":
        log = []
        name = body["name"].strip() or "SUNDAY"
        out_dir = body.get("out_folder") or default_out_dir(body, s)
        out = os.path.join(out_dir, name + " Project", name + ".als")
        if os.path.exists(out) and not body.get("overwrite"):
            raise ValueError("%s already exists. Pick another name or tick Overwrite." % out)
        builder.build_set(body.get("template") or s["template"], body["songs"], out,
                          gap_bars=int(body.get("gap_bars", s["gap_bars"])),
                          copy_audio=bool(body.get("copy_audio", s["copy_audio"])),
                          log=log.append, memory_files=memory_files())
        return {"path": out, "log": log}
    raise NotFound(path)


class NotFound(Exception):
    pass


_PKG = os.path.join(ROOT_DIR, "sessionbuilder")


def _code_stamp():
    t = 0
    for f in os.listdir(_PKG):
        if f.endswith(".py"):
            try:
                t = max(t, os.path.getmtime(os.path.join(_PKG, f)))
            except OSError:
                pass
    return t


_STARTED_STAMP = _code_stamp()
_RESTARTING = threading.Event()


def _restart():
    """Re-launch ourselves so newly installed code takes effect."""
    os.chdir(ROOT_DIR)
    os.execv(sys.executable, [sys.executable, "-m", "sessionbuilder.app", "--no-browser"])


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, data, ctype="application/json"):
        b = data if isinstance(data, bytes) else json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _handle(self, body):
        u = urlparse(self.path)
        if u.path.startswith("/api/") and (_RESTARTING.is_set() or _code_stamp() != _STARTED_STAMP):
            # Session Builder was updated on disk: answer, then restart with the new code.
            self._send(503, {"error": "Session Builder was just updated - reloading…", "restarting": True})
            if not _RESTARTING.is_set():
                _RESTARTING.set()
                threading.Timer(0.3, _restart).start()
            return
        if u.path == "/pco/login":
            from . import pco
            st = settings()
            if not (st["pco_client_id"] and st["pco_client_secret"]):
                return self._page("Add your Planning Center app's Client ID and Secret in Settings first.")
            self.send_response(302)
            self.send_header("Location", pco.login_url(st["pco_client_id"], REDIRECT))
            return self.end_headers()
        if u.path == "/pco/callback":
            from . import pco
            q = parse_qs(u.query)
            if "error" in q:
                return self._page("Planning Center sign-in was cancelled: %s" % q["error"][0])
            try:
                st = settings()
                church = pco.finish_login(st["pco_client_id"], st["pco_client_secret"], q["code"][0], q["state"][0])
                return self._page("Connected to <b>%s</b>." % church, ok=True)
            except Exception as e:
                return self._page("Sign-in failed: %s" % e)
        if u.path in ("/icon.png", "/apple-touch-icon.png", "/favicon.ico"):
            f = os.path.join(ROOT_DIR, "resources", "icon.png")
            if os.path.exists(f):
                with open(f, "rb") as fh:
                    return self._send(200, fh.read(), "image/png")
        if u.path in ("/", "/index.html"):
            with open(os.path.join(ROOT_DIR, "sessionbuilder", "ui.html"), "rb") as f:
                return self._send(200, f.read(), "text/html; charset=utf-8")
        try:
            self._send(200, api(u.path, parse_qs(u.query), body))
        except NotFound as e:
            self._send(404, {"error": "Session Builder needs a restart to finish updating. Close the Terminal window and open Session Builder again. (%s)" % e})
        except Exception as e:  # report to the UI
            traceback.print_exc()
            self._send(400, {"error": str(e)})

    def _page(self, msg, ok=False):
        html = ("<!doctype html><meta charset=utf-8><title>Planning Center</title>"
                "<body style='background:#1b1c1e;color:#e9e9ea;font:16px -apple-system,sans-serif;"
                "display:grid;place-items:center;height:90vh'><div style='max-width:520px;text-align:center'>"
                "<p>%s</p>%s</div>"
                % (msg, ("<p>Part of another church in Planning Center?</p><p>"
                         "<a style='background:#ff9f1a;color:#1a1205;padding:9px 16px;border-radius:8px;text-decoration:none;font-weight:600' href='/pco/login'>Add another church</a>"
                         "&nbsp;&nbsp;<a style='color:#ff9f1a' href='/?pco=1'>I'm done</a></p>") if ok
                        else "<p><a style='color:#ff9f1a' href='/'>Back to Session Builder</a></p>"))
        self._send(200, html.encode(), "text/html; charset=utf-8")

    def do_GET(self):
        self._handle(None)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        self._handle(json.loads(self.rfile.read(n) or b"{}"))


PCO_STATUS = {"msg": ""}


def migrate_pat_keys():
    """Keys from Planning Center's Personal Access Token page (secret starts with
    pco_pat_) were pasted into the OAuth fields: connect them as a token instead."""
    st = settings()
    cid, sec = st["pco_client_id"].strip(), st["pco_client_secret"].strip()
    if not (cid and sec.startswith("pco_pat_")):
        return
    from . import pco
    try:
        church = pco.add_token_account(cid, sec)
        save_settings({"pco_client_id": "", "pco_client_secret": ""})
        PCO_STATUS["msg"] = "Connected %s with your Personal Access Token." % church
    except Exception as e:
        PCO_STATUS["msg"] = "Couldn't connect your Personal Access Token: %s" % e


SERVER = {}
LIFE = {"last_ping": None, "busy": 0}
IDLE_MINUTES = 15


def _idle_watch():
    import time
    while True:
        time.sleep(30)
        lp = LIFE["last_ping"]
        if lp and not LIFE["busy"] and time.time() - lp > IDLE_MINUTES * 60:
            print("No window open for %d minutes - quitting." % IDLE_MINUTES)
            SERVER["srv"].shutdown()
            return


def main():
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    SERVER["srv"] = srv
    url = "http://localhost:%d" % PORT
    print("Session Builder running at " + url + "  (close this window to quit)")
    migrate_pat_keys()
    threading.Thread(target=lambda: (learn_sessions(), learn_cue_words()), daemon=True).start()
    st = settings()
    if st["pco_client_id"]:
        from . import pco
        threading.Thread(target=pco.refresh_all, args=(st["pco_client_id"], st["pco_client_secret"]), daemon=True).start()
    if "--idle-quit" in sys.argv:
        threading.Thread(target=_idle_watch, daemon=True).start()
    if "--no-browser" not in sys.argv:
        threading.Timer(0.7, lambda: webbrowser.open(url)).start()
    srv.serve_forever()


if __name__ == "__main__":
    main()
