"""Low-level Ableton Live Set (.als) helpers.

An .als file is gzip-compressed XML.  This module loads/saves sets, hands out
fresh pointee ids, and builds new tracks/clips by cloning prototype elements
taken from real Live 12 sets, so everything we write matches Live's schema.
"""
import copy
import gzip
import os
import xml.etree.ElementTree as ET

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROTO_PATH = os.path.join(ROOT_DIR, "resources", "prototypes.als")
# Where settings, picks and caches are written. The shared app keeps them in
# ~/Library/Application Support/SessionBuilder (set by the launcher).
DATA_DIR = os.environ.get("SB_DATA_DIR") or ROOT_DIR
os.makedirs(DATA_DIR, exist_ok=True)

FIRST_EVENT_TIME = "-63072000"   # Live's "before the song starts" event time


def load(path):
    with open(path, "rb") as f:
        data = f.read()
    try:
        if data[:2] == b"\x1f\x8b":
            data = gzip.decompress(data)
        return ET.ElementTree(ET.fromstring(data))
    except (OSError, EOFError, ET.ParseError):
        raise ValueError("Couldn't read %s - the Ableton file looks damaged or incomplete. "
                         "Open it in Ableton and re-save it, or pick another set." % os.path.basename(path))


def save(tree, path):
    root = tree.getroot()
    ET.indent(tree, space="\t") if hasattr(ET, "indent") else None
    xml = b'<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="utf-8")
    tmp = path + ".tmp"
    with gzip.open(tmp, "wb") as f:
        f.write(xml)
    os.replace(tmp, path)


def val(el, path, default=None):
    if el is None:
        return default
    x = el.find(path)
    if x is None:
        return default
    return x.get("Value", default)


def setv(el, path, value):
    x = el.find(path)
    if x is None:
        raise KeyError(path)
    if isinstance(value, bool):
        value = "true" if value else "false"
    elif isinstance(value, float):
        value = repr(value)
    x.set("Value", str(value))


def fmt(x):
    """Format a beat time the way Live does (no trailing .0)."""
    if abs(x - round(x)) < 1e-9:
        return str(int(round(x)))
    return repr(float(x))


def track_name(t):
    return val(t, "Name/EffectiveName", "") or val(t, "Name/UserName", "")


# Tags whose Id attribute lives in the set-wide "pointee" id space.
def _is_pointee_tag(tag):
    return tag in ("AutomationTarget", "ModulationTarget", "Pointee") or tag.endswith("ModulationTarget")


class IdAllocator:
    def __init__(self, liveset):
        self.liveset = liveset
        self.next = int(val(liveset, "NextPointeeId", "1"))
        # Track ids live in their own (small) range.
        used = [int(t.get("Id")) for t in liveset.find("Tracks")]
        mt = liveset.find("MainTrack")
        self.next_track = max(used + [0]) + 1

    def pointee(self):
        n = self.next
        self.next += 1
        return n

    def track(self):
        n = self.next_track
        self.next_track += 1
        return n

    def renumber(self, el):
        """Give every pointee inside a cloned element a fresh id."""
        for e in el.iter():
            if "Id" in e.attrib and _is_pointee_tag(e.tag):
                e.set("Id", str(self.pointee()))

    def commit(self):
        setv(self.liveset, "NextPointeeId", self.next)


SEND_OFF = 0.0003162277571   # Live's minimum send value (-inf dB)


class Prototypes:
    """Template elements cloned to make new tracks and clips."""

    def __init__(self, path=PROTO_PATH):
        ls = load(path).getroot().find("LiveSet")
        tracks = {track_name(t): t for t in ls.find("Tracks")}
        self.audio_track = tracks["PROTO AUDIO"]
        self.group_track = tracks["PROTO GROUP"]
        self.midi_track = tracks["PROTO MIDI"]
        self.audio_clip = self.audio_track.find(
            "DeviceChain/MainSequencer/Sample/ArrangerAutomation/Events/AudioClip")
        self.midi_clip = self.midi_track.find(
            "DeviceChain/MainSequencer/ClipTimeable/ArrangerAutomation/Events/MidiClip")
        self.locator = ls.find("Locators/Locators/Locator")
        self.clip_slot = copy.deepcopy(self.audio_track.find("DeviceChain/MainSequencer/ClipSlotList/ClipSlot"))
        self.clip_slot.find("ClipSlot/Value")[:] = []
        self.group_slot = copy.deepcopy(self.group_track.find("Slots/GroupTrackSlot"))
        self.send_holder = copy.deepcopy(self.audio_track.find("DeviceChain/Mixer/Sends/TrackSendHolder"))
        for el in (self.audio_track, self.group_track, self.midi_track):
            _clear_track(el)


def _clear_track(t):
    """Strip clips, automation, sends and session clip slots from a prototype track."""
    for ev in list(t.iter("Events")):
        ev[:] = []
    for env in list(t.iter("Envelopes")):
        env[:] = []
    for e in list(t.iter("ClipSlotList")):
        e[:] = []
    for path in ("Slots", "DeviceChain/Mixer/Sends"):
        x = t.find(path)
        if x is not None:
            x[:] = []


def _routing(dc, which, target, upper, lower=""):
    r = dc.find(which)
    setv(r, "Target", target)
    setv(r, "UpperDisplayString", upper)
    setv(r, "LowerDisplayString", lower)


def fill_track_slots(track, protos, n_scenes, sends, ids):
    """Give a new track one empty clip slot per scene and one send per return.
    sends: list of floats (1.0 = 0 dB), one per return track."""
    for path in ("DeviceChain/MainSequencer/ClipSlotList", "DeviceChain/FreezeSequencer/ClipSlotList"):
        dst = track.find(path)
        if dst is None:
            continue
        for i in range(n_scenes):
            s = copy.deepcopy(protos.clip_slot)
            s.set("Id", str(i))
            dst.append(s)
    if track.tag == "GroupTrack":
        dst = track.find("Slots")
        for i in range(n_scenes):
            s = copy.deepcopy(protos.group_slot)
            s.set("Id", str(i))
            dst.append(s)
    holders = track.find("DeviceChain/Mixer/Sends")
    for i, level in enumerate(sends):
        h = copy.deepcopy(protos.send_holder)
        h.set("Id", str(i))
        ids.renumber(h)
        setv(h, "Send/Manual", max(float(level), SEND_OFF))
        holders.append(h)


def new_track(kind, protos, ids, name, color, group_id=-1):
    src = {"audio": protos.audio_track, "group": protos.group_track, "midi": protos.midi_track}[kind]
    t = copy.deepcopy(src)
    t.set("Id", str(ids.track()))
    ids.renumber(t)
    setv(t, "Name/EffectiveName", name)
    setv(t, "Name/UserName", name)
    setv(t, "Color", color)
    setv(t, "TrackGroupId", group_id)
    return t


def route_output(track, mode):
    dc = track.find("DeviceChain")
    if mode == "group":
        _routing(dc, "AudioOutputRouting", "AudioOut/GroupTrack", "Group")
    elif mode == "sends":
        _routing(dc, "AudioOutputRouting", "AudioOut/None", "Sends Only")
    else:
        _routing(dc, "AudioOutputRouting", "AudioOut/Main", "Main")


def set_midi_output(track, routing):
    """routing: {Target, UpperDisplayString, LowerDisplayString} from a past session."""
    r = track.find("DeviceChain/MidiOutputRouting")
    if r is None or not routing or not routing.get("Target"):
        return
    for k in ("Target", "UpperDisplayString", "LowerDisplayString"):
        if r.find(k) is not None:
            setv(r, k, routing.get(k, ""))


def set_mixer(track, volume=1.0, on=True):
    setv(track, "DeviceChain/Mixer/Volume/Manual", float(volume))
    setv(track, "DeviceChain/Mixer/Speaker/Manual", bool(on))


def audio_events(track):
    return track.find("DeviceChain/MainSequencer/Sample/ArrangerAutomation/Events")


def midi_events(track):
    return track.find("DeviceChain/MainSequencer/ClipTimeable/ArrangerAutomation/Events")


def make_audio_clip(protos, clip_id, c, pos, color):
    """c: songs.Clip. pos: absolute arrangement start (beats)."""
    e = copy.deepcopy(protos.audio_clip)
    e.set("Id", str(clip_id))
    length = c.end - c.start
    start = pos + c.start
    e.set("Time", fmt(start))
    setv(e, "CurrentStart", fmt(start))
    setv(e, "CurrentEnd", fmt(start + length))
    setv(e, "Loop/LoopStart", fmt(c.loop_start))
    setv(e, "Loop/LoopEnd", fmt(c.loop_end))
    setv(e, "Loop/StartRelative", fmt(c.start_relative))
    setv(e, "Loop/LoopOn", c.loop_on)
    setv(e, "Loop/OutMarker", fmt(c.loop_end))
    setv(e, "Loop/HiddenLoopStart", fmt(c.loop_start))
    setv(e, "Loop/HiddenLoopEnd", fmt(c.loop_end))
    setv(e, "Name", c.name)
    setv(e, "Color", color)
    setv(e, "IsWarped", c.warped)
    setv(e, "WarpMode", c.warp_mode)
    setv(e, "PitchCoarse", c.pitch_coarse)
    setv(e, "PitchFine", c.pitch_fine)
    setv(e, "SampleVolume", c.gain)
    setv(e, "Fades/FadeInLength", fmt(c.fade_in))
    setv(e, "Fades/FadeOutLength", fmt(c.fade_out))
    # file reference: absolute path; Live resolves relative paths itself on Collect.
    fr = e.find("SampleRef/FileRef")
    setv(fr, "RelativePathType", 0)
    setv(fr, "RelativePath", "")
    setv(fr, "Path", c.path)
    setv(fr, "OriginalFileSize", c.file_size)
    setv(fr, "OriginalCrc", 0)
    setv(e, "SampleRef/LastModDate", int(c.mtime))
    setv(e, "SampleRef/DefaultDuration", int(c.frames))
    setv(e, "SampleRef/DefaultSampleRate", int(c.sample_rate))
    wm = e.find("WarpMarkers")
    wm[:] = []
    for i, (sec, beat) in enumerate(c.warp_markers):
        m = ET.SubElement(wm, "WarpMarker")
        m.set("Id", str(i))
        m.set("SecTime", repr(float(sec)))
        m.set("BeatTime", repr(float(beat)))
    e.find("SavedWarpMarkersForStretched")[:] = []
    return e


def make_midi_clip(protos, clip_id, start, end, name, color, keytracks=None):
    e = copy.deepcopy(protos.midi_clip)
    e.set("Id", str(clip_id))
    e.set("Time", fmt(start))
    length = end - start
    setv(e, "CurrentStart", fmt(start))
    setv(e, "CurrentEnd", fmt(end))
    setv(e, "Loop/LoopStart", "0")
    setv(e, "Loop/LoopEnd", fmt(length))
    setv(e, "Loop/StartRelative", "0")
    setv(e, "Loop/LoopOn", False)
    setv(e, "Loop/OutMarker", fmt(length))
    setv(e, "Loop/HiddenLoopStart", "0")
    setv(e, "Loop/HiddenLoopEnd", fmt(length))
    setv(e, "Name", name)
    setv(e, "Color", color)
    kt = e.find("Notes/KeyTracks")
    kt[:] = []
    max_note = 0
    for i, x in enumerate(keytracks or []):
        k = ET.fromstring(x)
        k.set("Id", str(i))
        for n in k.iter("MidiNoteEvent"):
            try:
                max_note = max(max_note, int(n.get("NoteId", 0)))
            except ValueError:
                pass
        kt.append(k)
    gen = e.find("Notes/NoteIdGenerator/NextId")
    if gen is not None:
        gen.set("Value", str(max_note + 1))
    return e


def make_locator(protos, loc_id, time, name):
    e = copy.deepcopy(protos.locator)
    e.set("Id", str(loc_id))
    setv(e, "Time", fmt(time))
    setv(e, "Name", name)
    setv(e, "IsSongStart", False)
    return e


# ---- master track automation (tempo + time signature) ----

def time_sig_value(num, den):
    dens = {1: 0, 2: 1, 4: 2, 8: 3, 16: 4}
    return dens.get(den, 2) * 99 + (num - 1)


def time_sig_from_value(v):
    v = int(v)
    return (v % 99) + 1, [1, 2, 4, 8, 16][v // 99]


def master_track(liveset):
    mt = liveset.find("MainTrack")
    return mt if mt is not None else liveset.find("MasterTrack")


def master_param(mt, tag):
    """The master track's Tempo / TimeSignature parameter (not a same-named element elsewhere)."""
    for path in ("DeviceChain/Mixer/" + tag, "MasterChain/Mixer/" + tag):
        x = mt.find(path)
        if x is not None and x.find("AutomationTarget") is not None:
            return x
    for x in mt.iter(tag):
        if x.find("AutomationTarget") is not None and x.find("Manual") is not None:
            return x
    for path in ("DeviceChain/Mixer/" + tag, "MasterChain/Mixer/" + tag):   # Live 8/9 style
        x = mt.find(path)
        if x is not None:
            return x
    return None


def _envelope_for(mt, param):
    at = param.find("AutomationTarget") if param is not None else None
    if at is None:
        return None
    tid = at.get("Id")
    envs = mt.find("AutomationEnvelopes/Envelopes")
    if envs is None:
        return None
    for env in envs:
        if val(env, "EnvelopeTarget/PointeeId") == tid:
            return env
    return None


def write_master_automation(liveset, tempo_points, sig_points, ids):
    """tempo_points / sig_points: lists of (time, value) in order (step changes
    are two points at the same time).  First point is the initial value."""
    mt = master_track(liveset)
    tempo = master_param(mt, "Tempo")
    sig = master_param(mt, "TimeSignature")
    if tempo is not None:
        setv(tempo, "Manual", float(tempo_points[0][1]))
    if sig is not None:
        setv(sig, "Manual", int(sig_points[0][1]))
    for param, pts, kind in ((tempo, tempo_points, "FloatEvent"), (sig, sig_points, "EnumEvent")):
        if param is None:
            continue
        env = _envelope_for(mt, param)
        if env is None:
            continue
        events = env.find("Automation/Events")
        events[:] = []
        for i, (t, v) in enumerate(pts):
            ev = ET.SubElement(events, kind)
            ev.set("Id", str(i))
            ev.set("Time", FIRST_EVENT_TIME if i == 0 else fmt(t))
            ev.set("Value", fmt(float(v)) if kind == "FloatEvent" else str(int(v)))


def read_master_automation(liveset):
    """{'tempo': [(time, bpm)], 'sig': [(time, enum)]} from Live 8-12 sets."""
    mt = master_track(liveset)
    out = {}
    for name, tag, default in (("tempo", "Tempo", 120.0), ("sig", "TimeSignature", 201.0)):
        param = master_param(mt, tag) if mt is not None else None
        pts = []
        if param is not None:
            env = _envelope_for(mt, param)
            if env is not None:
                for ev in env.find("Automation/Events"):
                    pts.append((float(ev.get("Time")), float(ev.get("Value"))))
            old = param.find("ArrangerAutomation/Events")         # Live 8/9
            if not pts and old is not None:
                for ev in old:
                    if ev.get("Time") is not None and ev.get("Value") is not None:
                        pts.append((float(ev.get("Time")), float(ev.get("Value"))))
            if not pts and val(param, "Manual") is not None:
                pts = [(float(FIRST_EVENT_TIME), float(val(param, "Manual")))]
        if not pts:
            pts = [(float(FIRST_EVENT_TIME), default)]
        out[name] = pts
    return out
