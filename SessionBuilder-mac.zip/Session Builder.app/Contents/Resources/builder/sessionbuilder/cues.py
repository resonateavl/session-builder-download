"""Find section cues in a guide track ("Verse", "Chorus"... spoken one bar before
each section) and turn them into MARKERS clips.

Guide tracks are silent except for the spoken cues and count-ins, so the cue
*timing* comes straight from the audio. Section *names* come from the song's
Planning Center arrangement order when the number of sections lines up;
otherwise they're numbered (SECTION 1, 2 ...) for you to rename.
"""
import array
import math
import os
import re
import shutil
import subprocess
import tempfile
import wave

SR = 8000
WIN = 0.02

ABBREV = [
    (r"^(ci|count ?in)$", "COUNT IN"), (r"^(i|in|intro)\d*$", "INTRO"),
    (r"^(v|vs|verse)\s*(\d+)$", "VERSE {n}"), (r"^(v|vs|verse)$", "VERSE"),
    (r"^(pc|pre|pre ?chorus)\s*(\d*)$", "PRE CHORUS"), (r"^(c|ch|chorus)\s*(\d+)$", "CHORUS {n}"),
    (r"^(c|ch|chorus)$", "CHORUS"), (r"^(b|br|bridge)\s*(\d*)$", "BRIDGE"),
    (r"^(t|tag)\s*(\d*)$", "TAG"), (r"^(o|out|outro)$", "OUTRO"), (r"^(e|end|ending)$", "ENDING"),
    (r"^(it|int|interlude)\s*(\d*)$", "INTERLUDE"), (r"^(inst|instrumental)\s*(\d*)$", "INSTRUMENTAL"),
    (r"^(vamp)\s*(\d*)$", "VAMP"), (r"^(ref|refrain)\s*(\d*)$", "REFRAIN"),
    (r"^(ta|turn|turnaround)$", "TURNAROUND"), (r"^(br?k|breakdown)$", "BREAKDOWN"),
    (r"^(s|solo)$", "SOLO"), (r"^(post ?chorus|pch)$", "POST CHORUS"), (r"^(h|hook)$", "HOOK"),
]


def section_name(token):
    t = token.strip().lower().replace(".", "")
    for pat, name in ABBREV:
        m = re.match(pat, t)
        if m:
            nums = [g for g in m.groups() if g and g.isdigit()]
            return name.replace("{n}", nums[-1] if nums else "").strip()
    return token.strip().upper()


def _decode(path):
    """-> list of 16-bit samples at 8 kHz mono, using macOS afconvert or ffmpeg."""
    tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    tmp.close()
    try:
        if shutil.which("afconvert"):
            subprocess.run(["afconvert", "-f", "WAVE", "-d", "LEI16@%d" % SR, "-c", "1", path, tmp.name],
                           capture_output=True, timeout=180, check=True)
        elif shutil.which("ffmpeg"):
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", path, "-ac", "1", "-ar", str(SR), tmp.name],
                           capture_output=True, timeout=180, check=True)
        else:
            return None
        with wave.open(tmp.name) as w:
            a = array.array("h")
            a.frombytes(w.readframes(w.getnframes()))
            return a
    except (subprocess.SubprocessError, OSError, wave.Error):
        return None
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


def bursts(samples, thr_db=-40, gap=0.25, minlen=0.08):
    n = int(SR * WIN)
    env = []
    for i in range(0, len(samples) - n, n):
        s = 0
        for x in samples[i:i + n]:
            s += x * x
        env.append(math.sqrt(s / n))
    if not env:
        return []
    peak = max(env) or 1
    thr = peak * 10 ** (thr_db / 20.0)
    out, on, last = [], None, None
    for i, v in enumerate(env):
        t = i * WIN
        if v > thr:
            if on is None:
                on = t
            last = t
        elif on is not None and t - last > gap:
            if last - on >= minlen:
                out.append((on, last + WIN))
            on = None
    if on is not None and last - on >= minlen:
        out.append((on, last + WIN))
    return out


NOT_CUE = "_NOT_CUE"
WORD_GAP = 0.06


def first_word(samples, on, off):
    """The cue word only: stop at the first short pause (drops a count right after it)."""
    a, b = int(on * SR), int(off * SR)
    sub = bursts(samples[a:b], thr_db=-34, gap=WORD_GAP, minlen=0.06) if b - a > SR * 0.3 else []
    if not sub:
        return on, off
    return on + sub[0][0], on + sub[0][1]
_DECODED = {}


def _decoded(path):
    if path not in _DECODED:
        if len(_DECODED) > 6:
            _DECODED.clear()
        _DECODED[path] = _decode(path)
    return _DECODED[path]


def _clip_bursts(clip):
    """Spoken bursts inside one arrangement clip -> [(arrangement_beat, samples, on, off)]."""
    samples = _decoded(clip.path)
    if not samples:
        return []
    to_beat = _sec_to_beat(clip)
    out = []
    for on, off in bursts(samples):
        bt = to_beat(on)
        if clip.start - 0.25 <= bt < clip.end - 0.25:
            out.append((bt, samples, on, off))
    return out


def detect_markers(song, guide_clips, sequence=None):
    """-> ([(start, end, name)], note) in song-relative beats, or (None, reason).
    guide_clips: every clip on the guide track (a guide can be split into several)."""
    if not isinstance(guide_clips, (list, tuple)):
        guide_clips = [guide_clips]
    if not song.bpm:
        return None, "no BPM"
    allb = []
    for c in sorted(guide_clips, key=lambda c: c.start):
        allb += _clip_bursts(c)
    if not allb:
        return None, "couldn't read the guide audio, or it has no spoken cues"
    allb.sort(key=lambda x: x[0])
    first = min(c.start for c in guide_clips)

    # Count-in: anything spoken in the first 2 bars of the song.
    count_in_end = first + 8 if allb[0][0] < first + 4 else None
    # Section cues are spoken right on a bar line (counts like "3, 4" fall between).
    # Only the first word of a phrase can be a cue: speech within ~1.5 beats of the
    # previous word is the rest of the cue ("Verse... two") or a count ("...2, 3, 4").
    firsts = [x for k, x in enumerate(allb) if k == 0 or x[0] - allb[k - 1][0] > 1.6]
    cand = [x for x in firsts if abs(x[0] / 4.0 - round(x[0] / 4.0)) * 4 <= 0.6
            and (not count_in_end or x[0] >= count_in_end)]

    templates = load_templates()
    if templates:
        from .cuefeat import classify, embed
    starts, names = [], {}
    for bt, samples, on, off in cand:
        st = (round(bt / 4.0) + 1) * 4                # the cue is spoken in the bar before the section
        if starts and st - starts[-1] < 4:
            continue
        lab = None
        if templates:
            v = embed(samples, *first_word(samples, on, off))
            lab, conf = classify(v, templates) if v else (None, 0)
            if lab == NOT_CUE:
                continue                              # a count, a lyric prompt, etc. - not a section
        starts.append(st)
        names[st] = lab
    end = song.length + (-song.length % 4)
    lead = count_in_end or 0
    if starts and lead and starts[0] - lead >= 8:
        starts.insert(0, lead)                        # first section (intro) right after the count-in
        names[lead] = "INTRO"
    starts = [x for x in starts if x < end]
    if not starts:
        return None, "no section cues found in the guide"

    labels = [names.get(x) for x in starts]
    seq = [section_name(x) for x in (sequence or []) if str(x).strip()]
    if None in labels and seq and len(seq) == len(starts):
        labels = [l or q for l, q in zip(labels, seq)]
    labels = [l or ("INTRO" if k == 0 else "CUE") for k, l in enumerate(labels)]
    out = []
    if lead:
        out.append((float(first), float(lead), "COUNT IN"))
    for k, x in enumerate(starts):
        e = starts[k + 1] if k + 1 < len(starts) else end
        out.append((float(x), float(e), labels[k]))
    note = "%d sections, named from the guide's spoken cues" % len(starts) if templates else \
        "%d sections (cue-word examples missing - names are guesses)" % len(starts)
    return out, note


# ---------- learning cue words from songs that already have markers ----------

_TEMPLATES = None
TEMPLATE_FILES = []      # set by the app: [shipped file, learned file]


def load_templates():
    global _TEMPLATES
    if _TEMPLATES is None:
        import json
        ex = []
        for f in TEMPLATE_FILES or [os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                                 "resources", "cue_templates.json")]:
            try:
                with open(f) as fh:
                    ex += json.load(fh).get("examples", [])
            except (OSError, ValueError):
                pass
        _TEMPLATES = ex
    return _TEMPLATES


def reset_templates():
    global _TEMPLATES
    _TEMPLATES = None


def base_label(name):
    n = re.sub(r"[^A-Za-z ]+", " ", name or "").upper()
    n = re.sub(r"\s+", " ", n).strip()
    n = n.replace("PRECHORUS", "PRE CHORUS").replace("POSTCHORUS", "POST CHORUS")
    n = re.sub(r"\b(I|II|III|IV|X\d*)$", "", n).strip()
    return n


def _sec_to_beat(clip):
    wm = sorted(clip.warp_markers)
    base = clip.start - clip.loop_start

    def f(sec):
        if len(wm) >= 2:
            for (s0, b0), (s1, b1) in zip(wm, wm[1:]):
                if sec <= s1 or (s1, b1) == wm[-1]:
                    if s1 == s0:
                        return base + b0
                    return base + b0 + (sec - s0) * (b1 - b0) / (s1 - s0)
        return base + sec * 2.0
    return f


def harvest_song(song, guide_clips):
    """Labelled cue examples from a song whose markers are known: the word spoken
    1 bar before each marker, plus other bar-line speech labelled as 'not a cue'."""
    from .cuefeat import embed
    if not isinstance(guide_clips, (list, tuple)):
        guide_clips = [guide_clips]
    bs = []
    for c in guide_clips:
        bs += _clip_bursts(c)
    if not bs:
        return []
    first = min(c.start for c in guide_clips)
    mstarts = [a for a, _, _ in song.markers]
    out = []
    used = set()
    for a, b, name in song.markers:
        lab = base_label(name)
        if not lab or lab in ("COUNT IN", "COUNT", "CLICK", "END", "STOP") or a < first + 8:
            continue
        cand = [x for x in bs if a - 4.8 <= x[0] <= a - 3.2 and x[3] - x[2] < 2.5]
        if len(cand) != 1:
            continue
        bt, samples, on, off = cand[0]
        used.add(bt)
        v = embed(samples, *first_word(samples, on, off))
        if v:
            out.append([lab, v])
    for bt, samples, on, off in bs:
        if bt < first + 7.5 and off - on < 0.55:          # count-in words ("1, 2, 3, 4")
            v = embed(samples, *first_word(samples, on, off))
            if v:
                out.append([NOT_CUE, v])
            continue
        if bt in used or bt < first + 8 or abs(bt / 4.0 - round(bt / 4.0)) * 4 > 0.6:
            continue
        if any(abs(bt - (m - 4)) < 2.5 for m in mstarts):
            continue
        v = embed(samples, *first_word(samples, on, off))
        if v:
            out.append([NOT_CUE, v])
    return out
