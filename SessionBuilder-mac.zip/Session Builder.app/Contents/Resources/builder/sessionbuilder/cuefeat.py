"""Small, dependency-free voice features for recognising spoken guide cues
("Verse", "Chorus", "Bridge"...) by comparing them to labelled examples taken
from the user's own MultiTracks songs (guide cue + the marker it announces)."""
import cmath
import math

SR = 8000
N = 256           # FFT size (32 ms)
HOP = 128         # 16 ms
NMEL = 24
NCEP = 12
NFRAMES = 16      # every cue is resampled to this many frames


def _fft(x):
    n = len(x)
    if n <= 1:
        return x
    even = _fft(x[0::2])
    odd = _fft(x[1::2])
    out = [0] * n
    for k in range(n // 2):
        t = cmath.exp(-2j * math.pi * k / n) * odd[k]
        out[k] = even[k] + t
        out[k + n // 2] = even[k] - t
    return out


def _mel(f):
    return 2595 * math.log10(1 + f / 700.0)


def _imel(m):
    return 700 * (10 ** (m / 2595.0) - 1)


_FB = None
_WIN = [0.54 - 0.46 * math.cos(2 * math.pi * i / (N - 1)) for i in range(N)]
_DCT = [[math.cos(math.pi * k * (j + 0.5) / NMEL) for j in range(NMEL)] for k in range(1, NCEP + 1)]


def _filterbank():
    global _FB
    if _FB is None:
        lo, hi = _mel(100), _mel(3800)
        pts = [_imel(lo + (hi - lo) * i / (NMEL + 1)) for i in range(NMEL + 2)]
        bins = [int(p / SR * N) for p in pts]
        fb = []
        for m in range(1, NMEL + 1):
            a, b, c = bins[m - 1], bins[m], bins[m + 1]
            row = []
            for k in range(a, c + 1):
                if k < b:
                    w = (k - a) / float(max(b - a, 1))
                else:
                    w = (c - k) / float(max(c - b, 1))
                if w > 0:
                    row.append((k, w))
            fb.append(row)
        _FB = fb
    return _FB


def embed(samples, start, end):
    """samples: 8 kHz int16 sequence; start/end in seconds. -> fixed-length vector."""
    fb = _filterbank()
    a = max(0, int(start * SR) - HOP)
    b = min(len(samples), int(end * SR) + HOP)
    seg = samples[a:b]
    if len(seg) < N:
        return None
    frames = []
    for i in range(0, len(seg) - N, HOP):
        x = [seg[i + j] * _WIN[j] for j in range(N)]
        spec = _fft(x)
        pw = [abs(spec[k]) ** 2 for k in range(N // 2 + 1)]
        mel = [math.log(sum(pw[k] * w for k, w in row) + 1e-3) for row in fb]
        frames.append([sum(d[j] * mel[j] for j in range(NMEL)) for d in _DCT])
    if len(frames) < 3:
        return None
    # remove the average (loudness / mic colour), then resample in time
    mean = [sum(f[c] for f in frames) / len(frames) for c in range(NCEP)]
    frames = [[f[c] - mean[c] for c in range(NCEP)] for f in frames]
    out = []
    for t in range(NFRAMES):
        pos = t * (len(frames) - 1) / float(NFRAMES - 1)
        i = int(pos)
        f = pos - i
        j = min(i + 1, len(frames) - 1)
        out.extend(frames[i][c] * (1 - f) + frames[j][c] * f for c in range(NCEP))
    out.append(math.log(max(end - start, 0.05)) * 8.0)      # word length matters ("Verse" vs "Instrumental")
    norm = math.sqrt(sum(v * v for v in out)) or 1.0
    return [round(v / norm, 4) for v in out]


def dist(a, b):
    return sum((x - y) ** 2 for x, y in zip(a, b))


def classify(vec, templates, k=5):
    """templates: [[label, vec], ...]  -> (label, confidence 0..1)"""
    best = sorted(((dist(vec, v), lab) for lab, v in templates), key=lambda x: x[0])[:k]
    if not best:
        return None, 0.0
    votes = {}
    for d, lab in best:
        votes[lab] = votes.get(lab, 0) + 1.0 / (d + 1e-3)
    lab = max(votes, key=votes.get)
    return lab, votes[lab] / sum(votes.values())
