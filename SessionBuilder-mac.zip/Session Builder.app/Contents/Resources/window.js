// Session Builder's own window (native macOS WebKit view, no browser).
// Run by the app launcher:  osascript -l JavaScript window.js <url> <icon.icns>
ObjC.import('Cocoa');
ObjC.import('WebKit');

function run(argv) {
  try { return openWindow(argv); } catch (e) {
    // Couldn't make the built-in window: fall back to the default browser.
    $.NSWorkspace.sharedWorkspace.openURL($.NSURL.URLWithString(argv[0] || 'http://localhost:8765'));
  }
}

function openWindow(argv) {
  const URL = argv[0] || 'http://localhost:8765';
  const ICON = argv[1] || '';
  const app = $.NSApplication.sharedApplication;
  $.NSProcessInfo.processInfo.processName = 'Session Builder';
  app.setActivationPolicy($.NSApplicationActivationPolicyRegular);
  if (ICON) {
    const img = $.NSImage.alloc.initWithContentsOfFile(ICON);
    if (img && !img.isNil()) app.applicationIconImage = img;
  }

  // Close the window = quit the app (and stop the builder in the background).
  if (!$.SBAppDelegate) {
    ObjC.registerSubclass({
      name: 'SBAppDelegate',
      superclass: 'NSObject',
      protocols: ['NSApplicationDelegate'],
      methods: {
        'applicationShouldTerminateAfterLastWindowClosed:': {
          types: ['bool', ['id']], implementation: function (s) { return true; }
        },
        'applicationWillTerminate:': {
          types: ['void', ['id']], implementation: function (n) {
            try { $.NSString.stringWithContentsOfURLEncodingError($.NSURL.URLWithString(URL + '/api/quit'), 4, null); } catch (e) {}
          }
        }
      }
    });
  }
  const delegate = $.SBAppDelegate.alloc.init;
  app.delegate = delegate;

  // Menus (needed for Quit, Hide, and copy/paste in text boxes).
  const main = $.NSMenu.alloc.init;
  function menu(title, items) {
    const top = $.NSMenuItem.alloc.init;
    const m = $.NSMenu.alloc.initWithTitle(title);
    items.forEach(function (it) {
      if (!it) { m.addItem($.NSMenuItem.separatorItem); return; }
      const mi = m.addItemWithTitleActionKeyEquivalent(it[0], it[1], it[2] || '');
      if (it[3]) mi.keyEquivalentModifierMask = it[3];
    });
    top.submenu = m;
    main.addItem(top);
  }
  const CMD = $.NSEventModifierFlagCommand, SHIFT = $.NSEventModifierFlagShift, OPT = $.NSEventModifierFlagOption;
  menu('Session Builder', [
    ['Hide Session Builder', 'hide:', 'h'],
    ['Hide Others', 'hideOtherApplications:', 'h', CMD | OPT],
    null,
    ['Quit Session Builder', 'terminate:', 'q']
  ]);
  menu('Edit', [
    ['Undo', 'undo:', 'z'], ['Redo', 'redo:', 'z', CMD | SHIFT], null,
    ['Cut', 'cut:', 'x'], ['Copy', 'copy:', 'c'], ['Paste', 'paste:', 'v'], ['Select All', 'selectAll:', 'a']
  ]);
  menu('View', [['Reload', 'reload:', 'r']]);
  menu('Window', [['Minimize', 'performMiniaturize:', 'm'], ['Close', 'performClose:', 'w']]);
  app.mainMenu = main;

  const rect = $.NSMakeRect(0, 0, 1440, 920);
  const style = $.NSWindowStyleMaskTitled | $.NSWindowStyleMaskClosable |
                $.NSWindowStyleMaskMiniaturizable | $.NSWindowStyleMaskResizable;
  const win = $.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer(rect, style, $.NSBackingStoreBuffered, false);
  win.title = 'Session Builder';
  win.minSize = $.NSMakeSize(900, 600);
  win.releasedWhenClosed = false;
  win.center;
  win.setFrameAutosaveName('SessionBuilderMain');

  const conf = $.WKWebViewConfiguration.alloc.init;
  const web = $.WKWebView.alloc.initWithFrameConfiguration(rect, conf);
  web.autoresizingMask = $.NSViewWidthSizable | $.NSViewHeightSizable;
  web.loadRequest($.NSURLRequest.requestWithURL($.NSURL.URLWithString(URL)));
  win.contentView = web;

  win.makeKeyAndOrderFront(null);
  app.activateIgnoringOtherApps(true);
  app.run;
}
